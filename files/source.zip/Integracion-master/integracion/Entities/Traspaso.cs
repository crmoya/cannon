﻿using System;
using System.ComponentModel;

namespace Integracion.Entities
{
    public class Traspaso
    {
        public int Id { get; set; }
        public int DocumentoId { get; set; }
        public Documento Documento { get; set; }
        public DateTime Fecha { get; set; }

        [DefaultValue(true)]
        public bool Procesado { get; set; }
    }
}
