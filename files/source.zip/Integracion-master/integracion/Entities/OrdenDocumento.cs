﻿using System.ComponentModel.DataAnnotations;

namespace Integracion.Entities
{
    public class OrdenDocumento
    {
        public int Id { get; set; }
        [Required]
        public int OrdenId { get; set; }
        public OrdenProcesada Orden { get; set; }
        [Required]
        public int DocumentoId { get; set; }
        public Documento Documento { get; set; }
    }
}
