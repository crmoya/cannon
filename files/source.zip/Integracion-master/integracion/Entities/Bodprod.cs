﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace Integracion.Entities
{
    [Table("BODPROD")]
    public partial class Bodprod
    {
        [Key]
        [Column("CODPRO")]
        [StringLength(15)]
        public string Codpro { get; set; }
        [Key]
        [Column("CODBOD")]
        [StringLength(5)]
        public string Codbod { get; set; }
        [Column("STFI")]
        public double? Stfi { get; set; }
        [Column("COMPROMETIDO")]
        public double? Comprometido { get; set; }
    }
}
