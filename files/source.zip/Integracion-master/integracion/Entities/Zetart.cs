﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace Integracion.Entities
{
    [Keyless]
    [Table("ZETART")]
    [Index(nameof(Codpro), Name = "IX_ZETART_CODPRO")]
    [Index(nameof(Codpro), nameof(Salfinal), Name = "IX_ZETART_CODPRO_SALFINAL")]
    public partial class Zetart
    {
        [Column("EMPRESA")]
        [StringLength(20)]
        public string Empresa { get; set; }
        [Required]
        [Column("CODZET")]
        [StringLength(17)]
        public string Codzet { get; set; }
        [Column("CODPRO")]
        [StringLength(15)]
        public string Codpro { get; set; }
        [Column("DESCRI")]
        [StringLength(100)]
        public string Descri { get; set; }
        [Column("UMED")]
        [StringLength(10)]
        public string Umed { get; set; }
        [Column("CIFUNI")]
        public double? Cifuni { get; set; }
        [Column("CIFTOT")]
        public double? Ciftot { get; set; }
        [Column("CANTINI")]
        public double? Cantini { get; set; }
        [Column("SALINIC")]
        public double? Salinic { get; set; }
        [Column("SALFINAL")]
        public double? Salfinal { get; set; }
        [Column("CODNAB")]
        [StringLength(10)]
        public string Codnab { get; set; }
        [Column("DOCENT")]
        [StringLength(50)]
        public string Docent { get; set; }
        [Column("MONEDA")]
        [StringLength(2)]
        public string Moneda { get; set; }
        [Column("PARIDAD")]
        public double? Paridad { get; set; }
        [Column("TIPO", TypeName = "numeric(18, 0)")]
        public decimal? Tipo { get; set; }
        [Column("CODUME", TypeName = "numeric(18, 0)")]
        public decimal? Codume { get; set; }
        [Column("BODENT")]
        [StringLength(10)]
        public string Bodent { get; set; }
        [Column("FECHA", TypeName = "datetime")]
        public DateTime? Fecha { get; set; }
    }
}
