﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace Integracion.Entities
{
    [Keyless]
    [Table("FACTAB")]
    public partial class Factab
    {
        [Column("EMPRESA")]
        [StringLength(20)]
        public string Empresa { get; set; }
        [Column("TIPO")]
        [StringLength(4)]
        public string Tipo { get; set; }
        [Column("CODIGO")]
        [StringLength(4)]
        public string Codigo { get; set; }
        [Column("DESCRIP")]
        [StringLength(50)]
        public string Descrip { get; set; }
        [Column("ATRIB_1")]
        [StringLength(12)]
        public string Atrib1 { get; set; }
        [Column("ATRIB_2")]
        [StringLength(12)]
        public string Atrib2 { get; set; }
        [Column("ATRIB_3")]
        [StringLength(12)]
        public string Atrib3 { get; set; }
        [Column("ATRIB_4")]
        [StringLength(12)]
        public string Atrib4 { get; set; }
    }
}
