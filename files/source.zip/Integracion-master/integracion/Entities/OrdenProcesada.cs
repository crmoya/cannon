﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Integracion.Entities
{
    public class OrdenProcesada
    {
        public int Id { get; set; }
        [Required]
        public DateTime FechaImportacion { get; set; }
        [Required]
        public string OrdenId { get; set; }
        public int EntityId { get; set; }
        public double? Despacho { get; set; }
        [Required]
        [DefaultValue(false)]
        public bool ConExcepcion { get; set; }
        public DateTime? FechaProcesamiento { get; set; }
        [Required]
        [DefaultValue(false)]
        public bool Pickeada { get; set; }

    }
}
