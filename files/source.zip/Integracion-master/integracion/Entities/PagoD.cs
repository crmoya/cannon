﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace Integracion.Entities
{
    [Table("PAGO_D")]
    [Index(nameof(Iddocto), Name = "IX_PAGO_D_IDDOCTO1")]
    [Index(nameof(Idpago), Name = "IX_PAGO_D_IDPAGO1")]
    public partial class PagoD
    {
        [Column("IDPAGO")]
        public int? Idpago { get; set; }
        [Key]
        [Column("IDPAGOD")]
        public int Idpagod { get; set; }
        [Column("IDDOCTO")]
        public int? Iddocto { get; set; }
        [Column("DOCREF")]
        [StringLength(10)]
        public string Docref { get; set; }
        [Column("FECPAG", TypeName = "datetime")]
        public DateTime? Fecpag { get; set; }
        [Column("VALDOLAR")]
        public double? Valdolar { get; set; }
        [Column("MONTO")]
        public double? Monto { get; set; }
        [Column("DIFTPC")]
        public double? Diftpc { get; set; }
        [Column("FECHAREAL", TypeName = "datetime")]
        public DateTime? Fechareal { get; set; }
        [Column("ESTADO")]
        [StringLength(1)]
        public string Estado { get; set; }
    }
}
