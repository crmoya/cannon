﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace Integracion.Entities
{
    [Keyless]
    [Table("usuarios")]
    public partial class Usuario
    {
        [Required]
        [Column("nombre")]
        [StringLength(50)]
        public string Nombre { get; set; }
        [Column("pwd")]
        [StringLength(50)]
        public string Pwd { get; set; }
        [Column("nom_usuario")]
        [StringLength(200)]
        public string NomUsuario { get; set; }
        [Column("inicio")]
        [StringLength(50)]
        public string Inicio { get; set; }
        [Column("cc")]
        [StringLength(50)]
        public string Cc { get; set; }
    }
}
