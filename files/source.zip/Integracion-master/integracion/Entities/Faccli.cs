﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace Integracion.Entities
{
    [Table("FACCLI")]
    [Index(nameof(Rut), Name = "IX_FACCLI_RUT")]
    public partial class Faccli
    {
        [Key]
        [Column("CODCLI")]
        [StringLength(20)]
        public string Codcli { get; set; }
        [Column("RUT")]
        [StringLength(20)]
        public string Rut { get; set; }
        [Column("DG")]
        [StringLength(1)]
        public string Dg { get; set; }
        [Column("TIPO")]
        [StringLength(1)]
        public string Tipo { get; set; }
        [Column("VIGENCIA")]
        [StringLength(1)]
        public string Vigencia { get; set; }
        [Column("NOMBRE")]
        [StringLength(50)]
        public string Nombre { get; set; }
        [Column("SIGLA")]
        [StringLength(20)]
        public string Sigla { get; set; }
        [Column("PAIS")]
        [StringLength(20)]
        public string Pais { get; set; }
        [Column("CIUDAD")]
        [StringLength(20)]
        public string Ciudad { get; set; }
        [Column("COMUNA")]
        [StringLength(20)]
        public string Comuna { get; set; }
        [Column("DIREC")]
        [StringLength(50)]
        public string Direc { get; set; }
        [Column("FONO")]
        [StringLength(20)]
        public string Fono { get; set; }
        [Column("FAX")]
        [StringLength(20)]
        public string Fax { get; set; }
        [Column("EMAIL")]
        [StringLength(40)]
        public string Email { get; set; }
        [Column("GIRO")]
        [StringLength(25)]
        public string Giro { get; set; }
        [Column("VEND")]
        [StringLength(5)]
        public string Vend { get; set; }
        [Column("ZONA")]
        [StringLength(4)]
        public string Zona { get; set; }
        [Column("COND_PAG")]
        [StringLength(4)]
        public string CondPag { get; set; }
        [Column("CRED_MAX")]
        public double? CredMax { get; set; }
        [Column("VIG_CRED", TypeName = "datetime")]
        public DateTime? VigCred { get; set; }
        [Column("LIS_PRE")]
        [StringLength(3)]
        public string LisPre { get; set; }
        [Column("COM_1")]
        [StringLength(50)]
        public string Com1 { get; set; }
        [Column("COM_2")]
        [StringLength(50)]
        public string Com2 { get; set; }
        [Column("COM_3")]
        [StringLength(50)]
        public string Com3 { get; set; }
        [Column("FEC_UL_COM", TypeName = "datetime")]
        public DateTime? FecUlCom { get; set; }
        [Column("RUT_FAC")]
        [StringLength(10)]
        public string RutFac { get; set; }
        [Column("DG2")]
        [StringLength(1)]
        public string Dg2 { get; set; }
        [Column("LPR")]
        [StringLength(50)]
        public string Lpr { get; set; }
        [Column("DES")]
        [StringLength(50)]
        public string Des { get; set; }
        [Column("FECHGRAB", TypeName = "datetime")]
        public DateTime? Fechgrab { get; set; }
        [Column("USUARIO")]
        [StringLength(50)]
        public string Usuario { get; set; }
        [Column("MODOPAGO")]
        [StringLength(10)]
        public string Modopago { get; set; }
        [Column("CLASIF")]
        public int? Clasif { get; set; }
        [Column("UBIC1")]
        [StringLength(20)]
        public string Ubic1 { get; set; }
        [Column("UBIC2")]
        [StringLength(3)]
        public string Ubic2 { get; set; }
        [Column("UBIC3")]
        [StringLength(3)]
        public string Ubic3 { get; set; }
        [Column("RUBRO")]
        [StringLength(20)]
        public string Rubro { get; set; }
    }
}
