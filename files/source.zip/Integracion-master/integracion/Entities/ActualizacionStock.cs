﻿using System;

namespace Integracion.Entities
{
    public class ActualizacionStock
    {
        public int Id { get; set; }
        public DateTime Fecha { get; set; }

    }
}
