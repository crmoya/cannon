﻿namespace Integracion.Entities
{
    public class PagoDocumento
    {
        public int Id { get; set; }
        public PagoE Pago { get; set; }
        public int PagoId { get; set; }        
        public Documento Documento { get; set; }
        public int DocumentoId { get; set; }
    }
}
