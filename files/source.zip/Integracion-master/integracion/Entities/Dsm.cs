﻿namespace Integracion.Entities
{
    public class Dsm
    {
        public int Id { get; set; }
        public int DocumentoId { get; set; }
        public Documento Documento { get; set; }
        public int NotaVentaId { get; set; }
        public Documento NotaVenta { get; set; }
        public string NumDocDsm { get; set; }
    }
}
