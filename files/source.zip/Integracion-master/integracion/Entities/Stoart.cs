﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace Integracion.Entities
{
    [Table("STOART")]
    public partial class Stoart
    {
        [Key]
        [Column("CODPRO")]
        [StringLength(15)]
        public string Codpro { get; set; }
        [Column("DESCRI")]
        [StringLength(50)]
        public string Descri { get; set; }
        [Column("UNIMED")]
        [StringLength(4)]
        public string Unimed { get; set; }
        [Column("FAMILIA")]
        [StringLength(20)]
        public string Familia { get; set; }
        [Column("SUBFAM")]
        [StringLength(20)]
        public string Subfam { get; set; }
        [Column("TIPO")]
        [StringLength(10)]
        public string Tipo { get; set; }
        [Column("SUBTIPO")]
        [StringLength(10)]
        public string Subtipo { get; set; }
        [Column("MONCOM")]
        [StringLength(3)]
        public string Moncom { get; set; }
        [Column("MONFAC")]
        [StringLength(3)]
        public string Monfac { get; set; }
        [Column("FECULEN", TypeName = "datetime")]
        public DateTime? Feculen { get; set; }
        [Column("FECULSA", TypeName = "datetime")]
        public DateTime? Feculsa { get; set; }
        [Column("FECCUMA", TypeName = "datetime")]
        public DateTime? Feccuma { get; set; }
        [Column("PUV")]
        public double? Puv { get; set; }
        [Column("CUUE")]
        public double? Cuue { get; set; }
        [Column("CUP")]
        public double? Cup { get; set; }
        [Column("CUP_MLOCAL")]
        public double? CupMlocal { get; set; }
        [Column("CUMA")]
        public double? Cuma { get; set; }
        [Column("MERMAC")]
        public double? Mermac { get; set; }
        [Column("CANSTO")]
        public double? Cansto { get; set; }
        [Column("STOMIN")]
        public double? Stomin { get; set; }
        [Column("STOMAX")]
        public double? Stomax { get; set; }
        [Column("VENTAAC")]
        public double? Ventaac { get; set; }
        [Column("COMPAC")]
        public double? Compac { get; set; }
        [Column("PROCED")]
        [StringLength(1)]
        public string Proced { get; set; }
        [Column("UBIC")]
        [StringLength(10)]
        public string Ubic { get; set; }
        [Column("COM_1")]
        [StringLength(20)]
        public string Com1 { get; set; }
        [Column("BMP")]
        [StringLength(12)]
        public string Bmp { get; set; }
        [Column("CODINT")]
        [StringLength(20)]
        public string Codint { get; set; }
        [Column("ESTADO")]
        [StringLength(1)]
        public string Estado { get; set; }
        [Column("STFI1")]
        public double? Stfi1 { get; set; }
        [Column("STFI2")]
        public double? Stfi2 { get; set; }
        [Column("STFI11")]
        public double? Stfi11 { get; set; }
        [Column("STFI15")]
        public double? Stfi15 { get; set; }
        [Column("PTES_MES")]
        public double? PtesMes { get; set; }
        [Column("KOPR")]
        [StringLength(13)]
        public string Kopr { get; set; }
        [Column("IMPUESTO")]
        [StringLength(1)]
        public string Impuesto { get; set; }
        [Column("COMPROMETIDO")]
        public double? Comprometido { get; set; }
        [Column("COMPOSICION")]
        [StringLength(25)]
        public string Composicion { get; set; }
        [Column("CODARAN")]
        [StringLength(50)]
        public string Codaran { get; set; }
        [Column("NOMZOFRI")]
        [StringLength(50)]
        public string Nomzofri { get; set; }
        [Column("COMPO")]
        [StringLength(50)]
        public string Compo { get; set; }
        [Column("FECHGRAB", TypeName = "datetime")]
        public DateTime? Fechgrab { get; set; }
        [Column("USUARIO")]
        [StringLength(50)]
        public string Usuario { get; set; }
        [Column("UNIMED2")]
        [StringLength(4)]
        public string Unimed2 { get; set; }
        [Column("UNISET")]
        public double? Uniset { get; set; }
        [Column("TIPOPROD")]
        [StringLength(1)]
        public string Tipoprod { get; set; }
    }
}
