﻿using Integracion.Models;
using Integracion.Utils;
using System;

namespace Integracion.Entities
{
    public class EventLog
    {
        public int Id { get; set; }
        public string Mensaje { get; set; }
        public LogType Tipo { get; set; }
        public DateTime Fecha { get; set; }
    }
}
