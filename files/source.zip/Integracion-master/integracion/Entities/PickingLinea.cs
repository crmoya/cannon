﻿namespace Integracion.Entities
{
    public class PickingLinea
    {
        public int Id { get; set; }
        public int LineaNotaVentaId { get; set; }
        public Documentod LineaNotaVenta { get; set; }
        public int PickingDetalleId { get; set; }
        public Documentod PickingDetalle { get; set; }
    }
}
