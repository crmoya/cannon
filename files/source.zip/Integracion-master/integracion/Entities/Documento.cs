﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace Integracion.Entities
{
    [Table("DOCUMENTO")]
    public partial class Documento
    {
        [Key]
        [Column("IDDOCTO")]
        public int Iddocto { get; set; }
        [Required]
        [Column("NUMDOC")]
        [StringLength(10)]
        public string Numdoc { get; set; }
        [Required]
        [Column("TD")]
        [StringLength(4)]
        public string Td { get; set; }
        [Column("CLASE")]
        [StringLength(3)]
        public string Clase { get; set; }
        [Column("FECDOC", TypeName = "datetime")]
        public DateTime? Fecdoc { get; set; }
        [Column("TDREF")]
        [StringLength(4)]
        public string Tdref { get; set; }
        [Column("DOCREF")]
        [StringLength(10)]
        public string Docref { get; set; }
        [Column("FECREF", TypeName = "datetime")]
        public DateTime? Fecref { get; set; }
        [Column("IDLEGAL")]
        [StringLength(10)]
        public string Idlegal { get; set; }
        [Column("BODENT")]
        [StringLength(4)]
        public string Bodent { get; set; }
        [Column("BODSAL")]
        [StringLength(4)]
        public string Bodsal { get; set; }
        [Column("MONEDA")]
        [StringLength(4)]
        public string Moneda { get; set; }
        [Column("PARIDAD")]
        public double? Paridad { get; set; }
        [Column("TOTDOC")]
        public double? Totdoc { get; set; }
        [Column("COMDOC")]
        [StringLength(100)]
        public string Comdoc { get; set; }
        [Column("CODVEND")]
        [StringLength(5)]
        public string Codvend { get; set; }
        [Column("CODLPR")]
        [StringLength(4)]
        public string Codlpr { get; set; }
        [Column("CODADUA")]
        [StringLength(4)]
        public string Codadua { get; set; }
        [Column("CODDEST")]
        [StringLength(4)]
        public string Coddest { get; set; }
        [Column("CODPAIS")]
        [StringLength(4)]
        public string Codpais { get; set; }
        [Column("CODTRAN")]
        [StringLength(4)]
        public string Codtran { get; set; }
        [Column("RESOLNUM")]
        [StringLength(10)]
        public string Resolnum { get; set; }
        [Column("RESOLDEC", TypeName = "datetime")]
        public DateTime? Resoldec { get; set; }
        [Column("CODSNA")]
        [StringLength(10)]
        public string Codsna { get; set; }
        [Column("BANCO")]
        [StringLength(10)]
        public string Banco { get; set; }
        [Column("CONDVTA")]
        [StringLength(50)]
        public string Condvta { get; set; }
        [Column("CODVIA")]
        [StringLength(4)]
        public string Codvia { get; set; }
        [Column("CODREPRES")]
        [StringLength(4)]
        public string Codrepres { get; set; }
        [Column("TDADUANA")]
        [StringLength(4)]
        public string Tdaduana { get; set; }
        [Column("RESPONSABLE")]
        [StringLength(3)]
        public string Responsable { get; set; }
        [Column("CODLOCAL")]
        [StringLength(3)]
        public string Codlocal { get; set; }
        [Column("PAGADO")]
        [StringLength(4)]
        public string Pagado { get; set; }
        [Column("VEND")]
        [StringLength(50)]
        public string Vend { get; set; }
        [Column("FEC_ENT", TypeName = "datetime")]
        public DateTime? FecEnt { get; set; }
        [Column("TPZETA")]
        [StringLength(50)]
        public string Tpzeta { get; set; }
        [Column("RUTFACTO")]
        [StringLength(50)]
        public string Rutfacto { get; set; }
        [Column("NOMFACTO")]
        [StringLength(200)]
        public string Nomfacto { get; set; }
        [Column("MTOIMPTO")]
        public double? Mtoimpto { get; set; }
        [Column("FOLIOLEGAL")]
        [StringLength(50)]
        public string Foliolegal { get; set; }
        [Column("FECHALEGAL", TypeName = "datetime")]
        public DateTime? Fechalegal { get; set; }
        [Column("FECHGRAB", TypeName = "datetime")]
        public DateTime? Fechgrab { get; set; }
        [Column("USUARIO")]
        [StringLength(50)]
        public string Usuario { get; set; }
        [Column("SALDO")]
        public double? Saldo { get; set; }
        [Column("IVA")]
        public double? Iva { get; set; }
        [Column("CENTRALIZADO")]
        [StringLength(4)]
        public string Centralizado { get; set; }
        [Column("BTP")]
        [StringLength(50)]
        public string Btp { get; set; }
        [Column("ESTADO")]
        [StringLength(50)]
        public string Estado { get; set; }
        [Column("TCPACTADO")]
        public double? Tcpactado { get; set; }
        [Column("PERIODO")]
        [StringLength(6)]
        public string Periodo { get; set; }
        [Column("HORAGRAB")]
        public TimeSpan? Horagrab { get; set; }
        [Column("IDBULTOS")]
        [StringLength(30)]
        public string Idbultos { get; set; }
        [Column("QTYBULTOS", TypeName = "numeric(18, 0)")]
        public decimal? Qtybultos { get; set; }
        [Column("CODAVANZ")]
        [StringLength(4)]
        public string Codavanz { get; set; }
        [Column("CODPROCEDENCIA")]
        [StringLength(4)]
        public string Codprocedencia { get; set; }
        [Column("CODREGION")]
        [StringLength(4)]
        public string Codregion { get; set; }
        [Column("CODZFE")]
        [StringLength(4)]
        public string Codzfe { get; set; }
    }
}
