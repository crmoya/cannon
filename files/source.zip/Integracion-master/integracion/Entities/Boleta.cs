﻿namespace Integracion.Entities
{
    public class Boleta
    {
        public int Id { get; set; }
        public int DocumentoId { get; set; }
        public Documento Documento { get; set; }
        public int NotaVentaId { get; set; }
        public Documento NotaVenta { get; set; }
        public string NumDocBoleta { get; set; }
    }
}
