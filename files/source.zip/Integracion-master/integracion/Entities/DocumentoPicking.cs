﻿using System;

namespace Integracion.Entities
{
    public class DocumentoPicking
    {
        public int Id { get; set; }
        public int NotaVentaId { get; set; }
        public Documento NotaVenta { get; set; }
        public int PickingId { get; set; }
        public Documento Picking { get; set; }
        public DateTime Fecha { get; set; }
    }
}
