﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace Integracion.Entities
{
    [Table("MODULO")]
    public partial class Modulo
    {
        [Key]
        [Column("modulo")]
        [StringLength(50)]
        public string Modulo1 { get; set; }
        [Column("caja")]
        [StringLength(3)]
        public string Caja { get; set; }
        [Column("bodega")]
        [StringLength(50)]
        public string Bodega { get; set; }
        [Column("lpr")]
        [StringLength(50)]
        public string Lpr { get; set; }
        [Column("factura")]
        [StringLength(50)]
        public string Factura { get; set; }
        [Column("boleta")]
        [StringLength(50)]
        public string Boleta { get; set; }
        [Column("NVV")]
        [StringLength(50)]
        public string Nvv { get; set; }
        [Column("PPE")]
        [StringLength(50)]
        public string Ppe { get; set; }
        [Column("OCC")]
        [StringLength(50)]
        public string Occ { get; set; }
        [Column("ncredito")]
        [StringLength(50)]
        public string Ncredito { get; set; }
        [Column("OCP")]
        [StringLength(50)]
        public string Ocp { get; set; }
        [Column("NCE")]
        [StringLength(50)]
        public string Nce { get; set; }
    }
}
