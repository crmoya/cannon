﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace Integracion.Entities
{
    [Keyless]
    [Table("PARAMETROS")]
    public partial class Parametro
    {
        [Column("ID")]
        public int Id { get; set; }
        [Column("manifiesto")]
        [StringLength(50)]
        public string Manifiesto { get; set; }
        [Column("numbl")]
        [StringLength(50)]
        public string Numbl { get; set; }
        [Column("fechabl", TypeName = "datetime")]
        public DateTime? Fechabl { get; set; }
        [Column("emisor")]
        [StringLength(50)]
        public string Emisor { get; set; }
        [Column("UBVA")]
        [StringLength(50)]
        public string Ubva { get; set; }
        [Column("UBVB")]
        [StringLength(50)]
        public string Ubvb { get; set; }
        [Column("UBVC")]
        [StringLength(50)]
        public string Ubvc { get; set; }
        [Column("rutempresa")]
        [StringLength(50)]
        public string Rutempresa { get; set; }
        [Column("dgempresa")]
        [StringLength(1)]
        public string Dgempresa { get; set; }
        [Column("nombreempresa")]
        [StringLength(200)]
        public string Nombreempresa { get; set; }
        [Column("direccion")]
        [StringLength(200)]
        public string Direccion { get; set; }
        [Column("direfacto")]
        [StringLength(200)]
        public string Direfacto { get; set; }
        [Column("repre")]
        [StringLength(200)]
        public string Repre { get; set; }
        [Column("bodprod")]
        [StringLength(50)]
        public string Bodprod { get; set; }
        [Column("bodcorte")]
        [StringLength(50)]
        public string Bodcorte { get; set; }
        [Column("bodent")]
        [StringLength(50)]
        public string Bodent { get; set; }
        [Column("bodarriendo")]
        [StringLength(50)]
        public string Bodarriendo { get; set; }
        [Column("desctopersonal")]
        public double? Desctopersonal { get; set; }
        [Column("montomaxper")]
        public double? Montomaxper { get; set; }
        [Column("fechaTope", TypeName = "datetime")]
        public DateTime? FechaTope { get; set; }
    }
}
