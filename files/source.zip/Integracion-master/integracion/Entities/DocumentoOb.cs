﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace Integracion.Entities
{
    [Table("DOCUMENTO_OBS")]
    [Index(nameof(Iddocto), Name = "IX_DOCUMENTO_OBS_IDDOCTO")]
    public partial class DocumentoOb
    {
        [Key]
        [Column("ID")]
        public int Id { get; set; }
        [Column("IDDOCTO")]
        public int? Iddocto { get; set; }
        [Column("OBS")]
        [StringLength(4000)]
        public string Obs { get; set; }
        [Column("IDBULTOS")]
        [StringLength(30)]
        public string Idbultos { get; set; }
        [Column("QTYBULTOS", TypeName = "numeric(18, 0)")]
        public decimal? Qtybultos { get; set; }
    }
}
