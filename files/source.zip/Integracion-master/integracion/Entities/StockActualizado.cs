﻿namespace Integracion.Entities
{
    public class StockActualizado
    {
        public int Id { get; set; }
        public int ActualizacionId { get; set; }
        public ActualizacionStock Actualizacion { get; set; }
        public string Sku { get; set; }
        public int IncrementoStock { get; set; }
    }
}
