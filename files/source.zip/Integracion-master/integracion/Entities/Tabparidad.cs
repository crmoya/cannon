﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace Integracion.Entities
{
    [Keyless]
    [Table("TABPARIDAD")]
    [Index(nameof(Fecha), Name = "IX_TABPARIDAD_FECHA1")]
    [Index(nameof(Moneda), nameof(Fecha), Name = "IX_TABPARIDAD_MONEDA_FECHA")]
    public partial class Tabparidad
    {
        [Column("MONEDA")]
        [StringLength(5)]
        public string Moneda { get; set; }
        [Column("FECHA", TypeName = "datetime")]
        public DateTime? Fecha { get; set; }
        [Column("VALOR")]
        public double? Valor { get; set; }
        [Column("DIA")]
        public int? Dia { get; set; }
    }
}
