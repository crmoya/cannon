﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace Integracion.Entities
{
    [Table("PAGO_E")]
    [Index(nameof(Bol), Name = "IX_PAGO_E_BOL")]
    [Index(nameof(Bol), nameof(Rut), nameof(Saldo), Name = "IX_PAGO_E_BOL_RUT_SALDO")]
    public partial class PagoE
    {
        [Key]
        [Column("IDPAGO")]
        public int Idpago { get; set; }
        [Column("RUT")]
        [StringLength(20)]
        public string Rut { get; set; }
        [Column("TP")]
        [StringLength(3)]
        public string Tp { get; set; }
        [Column("MONEDA")]
        [StringLength(4)]
        public string Moneda { get; set; }
        [Column("MONTO")]
        public double? Monto { get; set; }
        [Column("FECDOC", TypeName = "datetime")]
        public DateTime? Fecdoc { get; set; }
        [Column("FECVENC", TypeName = "datetime")]
        public DateTime? Fecvenc { get; set; }
        [Column("FECDEP", TypeName = "datetime")]
        public DateTime? Fecdep { get; set; }
        [Column("NUMCUENTA")]
        [StringLength(20)]
        public string Numcuenta { get; set; }
        [Column("NUMDOCPAGO")]
        [StringLength(20)]
        public string Numdocpago { get; set; }
        [Column("BANCO")]
        [StringLength(20)]
        public string Banco { get; set; }
        [Column("SALDO")]
        public double? Saldo { get; set; }
        [Column("MARK")]
        [StringLength(1)]
        public string Mark { get; set; }
        [Column("VALDOLAR")]
        public double? Valdolar { get; set; }
        [Column("BOL")]
        [StringLength(50)]
        public string Bol { get; set; }
        [Column("FECHAREAL", TypeName = "datetime")]
        public DateTime? Fechareal { get; set; }
        [Column("USUARIO")]
        [StringLength(10)]
        public string Usuario { get; set; }
        [Column("IMPRESION")]
        [StringLength(10)]
        public string Impresion { get; set; }
    }
}
