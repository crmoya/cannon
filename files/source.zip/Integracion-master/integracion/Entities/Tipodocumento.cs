﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace Integracion.Entities
{
    [Keyless]
    [Table("TIPODOCUMENTO")]
    public partial class Tipodocumento
    {
        [Required]
        [Column("CLASE")]
        [StringLength(3)]
        public string Clase { get; set; }
        [Column("TIPODOC")]
        [StringLength(5)]
        public string Tipodoc { get; set; }
        [Required]
        [Column("CODIDOC")]
        [StringLength(3)]
        public string Codidoc { get; set; }
        [Column("NAMEDOCUMENTO")]
        [StringLength(50)]
        public string Namedocumento { get; set; }
        [Column("MODULO")]
        [StringLength(20)]
        public string Modulo { get; set; }
        [Column("EXTRA")]
        [StringLength(50)]
        public string Extra { get; set; }
        [Column("SISTEMA")]
        [StringLength(1)]
        public string Sistema { get; set; }
        [Column("FACTORINVENTARIO")]
        public double? Factorinventario { get; set; }
        [Column("FACTORMONTO")]
        public double? Factormonto { get; set; }
        [Column("ID_SECUENCIA")]
        public int? IdSecuencia { get; set; }
        [Column("IMPUESTO")]
        [StringLength(3)]
        public string Impuesto { get; set; }
        [Column("FECHGRAB", TypeName = "datetime")]
        public DateTime? Fechgrab { get; set; }
        [Column("USUARIO")]
        [StringLength(50)]
        public string Usuario { get; set; }
        [Column("CUENTA")]
        [StringLength(12)]
        public string Cuenta { get; set; }
    }
}
