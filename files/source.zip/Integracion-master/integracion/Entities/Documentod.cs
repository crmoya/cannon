﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace Integracion.Entities
{
    [Table("DOCUMENTOD")]
    public partial class Documentod
    {
        [Key]
        [Column("IDDOCTOD")]
        public int Iddoctod { get; set; }
        [Column("IDDOCTO")]
        public int? Iddocto { get; set; }
        [Required]
        [Column("NUMDOC")]
        [StringLength(10)]
        public string Numdoc { get; set; }
        [Required]
        [Column("TD")]
        [StringLength(4)]
        public string Td { get; set; }
        [Column("SEC")]
        public double? Sec { get; set; }
        [Column("FECDOC", TypeName = "datetime")]
        public DateTime? Fecdoc { get; set; }
        [Column("CODPRO")]
        [StringLength(15)]
        public string Codpro { get; set; }
        [Column("CODZET")]
        [StringLength(17)]
        public string Codzet { get; set; }
        [Column("CIFUNI")]
        public double? Cifuni { get; set; }
        [Column("VTAUNI")]
        public double? Vtauni { get; set; }
        [Column("CANT")]
        public double? Cant { get; set; }
        [Column("TOTLIN")]
        public double? Totlin { get; set; }
        [Column("DESPACHA")]
        [StringLength(1)]
        public string Despacha { get; set; }
        [Column("ENTREGADA")]
        [StringLength(1)]
        public string Entregada { get; set; }
        [Column("DOCREF")]
        [StringLength(10)]
        public string Docref { get; set; }
        [Column("TDREF")]
        [StringLength(4)]
        public string Tdref { get; set; }
        [Column("SECREF")]
        public double? Secref { get; set; }
        [Column("CANTEX")]
        public double? Cantex { get; set; }
        [Column("CANTCE")]
        public double? Cantce { get; set; }
        [Column("FACTOR")]
        public double? Factor { get; set; }
        [Column("PARIDAD")]
        public double? Paridad { get; set; }
        [Column("RESPONSABLE")]
        [StringLength(5)]
        public string Responsable { get; set; }
        [Column("CODLOCAL")]
        [StringLength(3)]
        public string Codlocal { get; set; }
        [Column("CODBOD")]
        [StringLength(3)]
        public string Codbod { get; set; }
        [Column("CTOUNIT")]
        public double? Ctounit { get; set; }
        [Column("BULTOSREF")]
        [StringLength(250)]
        public string Bultosref { get; set; }
        [Column("IMPUESTO")]
        public double? Impuesto { get; set; }
        [Column("TPZETA")]
        [StringLength(50)]
        public string Tpzeta { get; set; }
    }
}
