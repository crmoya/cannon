﻿using System.ComponentModel.DataAnnotations;

namespace Integracion.Entities
{
    public class ExcepcionOrdenProcesada
    {
        public int Id { get; set; }
        [Required]
        public string Atributo { get; set; }
        public string Producto{ get; set; } 
        [Required]
        public string Excepcion { get; set; }
        [Required]
        public int? ProcesoId { get; set; }
        public OrdenProcesada Proceso { get; set; }
    }
}
