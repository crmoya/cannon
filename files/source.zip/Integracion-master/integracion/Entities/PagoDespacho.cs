﻿namespace Integracion.Entities
{
    public class PagoDespacho
    {
        public int Id { get; set; }
        public int PagoId { get; set; }
        public PagoE Pago { get; set; }
        public double? Monto { get; set; }

    }
}
