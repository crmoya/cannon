﻿using Integracion.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Integracion.Filters
{
    public class BeforeActionFilter : IActionFilter
    {

        private readonly IHttpContextAccessor _httpContextAccessor;

        public BeforeActionFilter(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }


        public void OnActionExecuting(ActionExecutingContext context)
        {

            var accion = context.RouteData.Values["action"].ToString().ToLower();
            var controlador = context.RouteData.Values["controller"].ToString().ToLower();

            if(controlador != "home" && accion != "login")
            {
                var usuario = _httpContextAccessor.HttpContext.Session.GetString("usuario");
                if(usuario == null)
                {
                    _httpContextAccessor.HttpContext.Response.Redirect("/Home/Login");
                }
            }
            
        }

        public void OnActionExecuted(ActionExecutedContext context)
        {
        }
    }
}