﻿using Integracion.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.IO;

#nullable disable

namespace Integracion.Data
{
    public partial class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }
        //tablas nuevas
        public virtual DbSet<EventLog> log_evento { get; set; }
        public virtual DbSet<ExcepcionOrdenProcesada> excepcion_orden { get; set; }
        public virtual DbSet<OrdenProcesada> orden_procesada { get; set; }
        public virtual DbSet<OrdenDocumento> orden_documento { get; set; }
        public virtual DbSet<PagoDocumento> pago_documento { get; set; }
        public virtual DbSet<Srf> srf { get; set; }
        public virtual DbSet<Dsm> dsm { get; set; }
        public virtual DbSet<Boleta> boleta { get; set; }
        public virtual DbSet<DocumentoPicking> documento_picking { get; set; }
        public virtual DbSet<PickingLinea> picking_linea { get; set; }
        public virtual DbSet<PagoDespacho> pago_despacho { get; set; }
        public virtual DbSet<Traspaso> traspaso { get; set; }
        public virtual DbSet<ActualizacionStock> actualizacion_stock { get; set; }
        public virtual DbSet<StockActualizado> stock_actualizado { get; set; }

        //tablas Sistema Iquique
        public virtual DbSet<Bodprod> bodega_producto { get; set; }
        public virtual DbSet<Documento> documento { get; set; }
        public virtual DbSet<Documentod> documento_detalle { get; set; }
        public virtual DbSet<Faccli> cliente { get; set; }
        public virtual DbSet<Stoart> stock_articulo { get; set; }
        public virtual DbSet<Tipodocumento> tipo_documento { get; set; }
        public virtual DbSet<Modulo> modulo { get; set; }
        public virtual DbSet<Tabparidad> paridad { get; set; }
        public virtual DbSet<PagoE> pago { get; set; }
        public virtual DbSet<PagoD> pago_detalle { get; set; }
        public virtual DbSet<Zetart> zetas { get; set; }
        public virtual DbSet<Factab> factabs { get; set; }
        public virtual DbSet<DocumentoOb> documento_observacion { get; set; }
        public virtual DbSet<Parametro> parametros { get; set; }
        public virtual DbSet<Usuario> usuarios { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<Bodprod>(entity =>
            {
                entity.HasKey(e => new { e.Codpro, e.Codbod });

                entity.HasIndex(e => e.Codbod, "IX_BODPROD_CODBOD")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Codbod, e.Codpro }, "IX_BODPROD_CODBOD_CODPRO")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Stfi, "IX_BODPROD_STFI")
                    .HasFillFactor((byte)100);

                entity.Property(e => e.Codpro).IsUnicode(false);

                entity.Property(e => e.Codbod).IsUnicode(false);

                entity.Property(e => e.Comprometido).HasDefaultValueSql("(0)");

                entity.Property(e => e.Stfi).HasDefaultValueSql("(0)");
            });

            modelBuilder.Entity<Documento>(entity =>
            {
                entity.HasIndex(e => new { e.Numdoc, e.Td }, "D1")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.Td, e.Idlegal }, "D2")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.Bodsal, e.Td, e.Fecdoc }, "IX_DOCUMENTO_BODSAL_TD_FECDOC")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Bodsal, e.Td, e.Fecdoc }, "IX_DOCUMENTO_BODSAL_TD_FECDOC2")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Fecdoc, "IX_DOCUMENTO_FECDOC")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Fecdoc, "IX_DOCUMENTO_FECDOC2")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Fecdoc, e.Foliolegal, e.Centralizado }, "IX_DOCUMENTO_FECDOC_FOLIOLEGAL_CENTRALIZADO")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Fecdoc, e.Idlegal, e.Saldo }, "IX_DOCUMENTO_FECDOC_IDLEGAL_SALDO")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Fecdoc, e.Td }, "IX_DOCUMENTO_FECDOC_TD1")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Fecdoc, e.Td }, "IX_DOCUMENTO_FECDOC_TD2")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Fecdoc, e.Td }, "IX_DOCUMENTO_FECDOC_TD3")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Fecdoc, e.Td }, "IX_DOCUMENTO_FECDOC_TD4")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Fecdoc, e.Td }, "IX_DOCUMENTO_FECDOC_TD5")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Foliolegal, "IX_DOCUMENTO_FOLIOLEGAL1")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Foliolegal, "IX_DOCUMENTO_FOLIOLEGAL2")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Foliolegal, "IX_DOCUMENTO_FOLIOLEGAL3")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Idlegal, "IX_DOCUMENTO_IDLEGAL1")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Idlegal, "IX_DOCUMENTO_IDLEGAL2")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Idlegal, "IX_DOCUMENTO_IDLEGAL3")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Idlegal, "IX_DOCUMENTO_IDLEGAL4")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Idlegal, "IX_DOCUMENTO_IDLEGAL5")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Idlegal, "IX_DOCUMENTO_IDLEGAL6")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Idlegal, "IX_DOCUMENTO_IDLEGAL7")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Td, "IX_DOCUMENTO_TD1")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Td, "IX_DOCUMENTO_TD2")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Td, "IX_DOCUMENTO_TD3")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Tdref, e.Docref }, "IX_DOCUMENTO_TDREF_DOCREF")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Bodsal, e.Fecdoc }, "IX_DOCUMENTO_TD_BODSAL_FECDOC")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Clase, e.Fecdoc }, "IX_DOCUMENTO_TD_CLASE_FECDOC")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Fecdoc }, "IX_DOCUMENTO_TD_FECDOC1")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Fecdoc }, "IX_DOCUMENTO_TD_FECDOC2")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Fecdoc }, "IX_DOCUMENTO_TD_FECDOC3")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Fecdoc, e.Idlegal, e.Rutfacto }, "IX_DOCUMENTO_TD_FECDOC_IDLEGAL_RUTFACTO")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Fecdoc, e.Idlegal, e.Saldo }, "IX_DOCUMENTO_TD_FECDOC_IDLEGAL_SALDO1")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Fecdoc, e.Idlegal, e.Saldo }, "IX_DOCUMENTO_TD_FECDOC_IDLEGAL_SALDO2")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Foliolegal }, "IX_DOCUMENTO_TD_FOLIOLEGAL")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Idlegal }, "IX_DOCUMENTO_TD_IDLEGAL1")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Idlegal }, "IX_DOCUMENTO_TD_IDLEGAL2")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Idlegal, e.Fecdoc }, "IX_DOCUMENTO_TD_IDLEGAL_FECDOC")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Tdaduana, e.Btp, e.Estado }, "IX_DOCUMENTO_TD_TDADUANA_BTP_ESTADO1")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Tdaduana, e.Btp, e.Estado }, "IX_DOCUMENTO_TD_TDADUANA_BTP_ESTADO2")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Tdref, e.Bodent }, "IX_DOCUMENTO_TD_TDREF_BODENT")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Tdref, e.Fecdoc }, "IX_DOCUMENTO_TD_TDREF_FECDOC")
                    .HasFillFactor((byte)100);

                entity.Property(e => e.Banco).IsFixedLength(true);

                entity.Property(e => e.Bodent).IsUnicode(false);

                entity.Property(e => e.Bodsal).IsUnicode(false);

                entity.Property(e => e.Centralizado).IsUnicode(false);

                entity.Property(e => e.Clase)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Codadua).IsUnicode(false);

                entity.Property(e => e.Codavanz).IsUnicode(false);

                entity.Property(e => e.Coddest).IsUnicode(false);

                entity.Property(e => e.Codlocal)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Codlpr).IsUnicode(false);

                entity.Property(e => e.Codpais).IsUnicode(false);

                entity.Property(e => e.Codprocedencia).IsUnicode(false);

                entity.Property(e => e.Codregion).IsUnicode(false);

                entity.Property(e => e.Codrepres).IsUnicode(false);

                entity.Property(e => e.Codsna).IsFixedLength(true);

                entity.Property(e => e.Codtran).IsUnicode(false);

                entity.Property(e => e.Codvend).IsUnicode(false);

                entity.Property(e => e.Codvia).IsUnicode(false);

                entity.Property(e => e.Codzfe).IsUnicode(false);

                entity.Property(e => e.Comdoc).IsUnicode(false);

                entity.Property(e => e.Docref).IsUnicode(false);

                entity.Property(e => e.Estado).HasDefaultValueSql("(N'T')");

                entity.Property(e => e.Idbultos).IsUnicode(false);

                entity.Property(e => e.Idlegal).IsUnicode(false);

                entity.Property(e => e.Moneda).IsUnicode(false);

                entity.Property(e => e.Numdoc)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Pagado)
                    .IsUnicode(false)
                    .HasDefaultValueSql("('NO')");

                entity.Property(e => e.Periodo).IsUnicode(false);

                entity.Property(e => e.Resolnum).IsUnicode(false);

                entity.Property(e => e.Responsable)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Td).IsUnicode(false);

                entity.Property(e => e.Tdaduana).IsUnicode(false);

                entity.Property(e => e.Tdref).IsUnicode(false);
            });

            modelBuilder.Entity<Documentod>(entity =>
            {
                entity.HasIndex(e => new { e.Iddocto, e.Codpro }, "CI")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => e.Iddocto, "DD1")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.Numdoc, e.Td }, "DD2")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.Fecdoc, e.Codbod }, "DD3")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => new { e.Codpro, e.Fecdoc }, "F")
                    .HasFillFactor((byte)80);

                entity.HasIndex(e => e.Codpro, "IX_DOCUMENTOD_CODPRO1")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Codpro, e.Codzet, e.Docref }, "IX_DOCUMENTOD_CODPRO_CODZET_DOCREF")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Docref, e.Tdref }, "IX_DOCUMENTOD_DOCREF_TDREF")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Fecdoc, "IX_DOCUMENTOD_FECDOC1")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Fecdoc, "IX_DOCUMENTOD_FECDOC2")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Fecdoc, "IX_DOCUMENTOD_FECDOC3")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Fecdoc, "IX_DOCUMENTOD_FECDOC4")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Fecdoc, "IX_DOCUMENTOD_FECDOC5")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Fecdoc, "IX_DOCUMENTOD_FECDOC6")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Fecdoc, "IX_DOCUMENTOD_FECDOC7")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Fecdoc, "IX_DOCUMENTOD_FECDOC8")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Fecdoc, e.Codbod }, "IX_DOCUMENTOD_FECDOC_CODBOD1")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Fecdoc, e.Codbod }, "IX_DOCUMENTOD_FECDOC_CODBOD2")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Fecdoc, e.Td }, "IX_DOCUMENTOD_FECDOC_TD2")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Td, "IX_DOCUMENTOD_TD1")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Td, "IX_DOCUMENTOD_TD2")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Td, "IX_DOCUMENTOD_TD3")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Td, "IX_DOCUMENTOD_TD4")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Td, "IX_DOCUMENTOD_TD5")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Td, "IX_DOCUMENTOD_TD6")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Td, "IX_DOCUMENTOD_TD7")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Td, "IX_DOCUMENTOD_TD8")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Codzet }, "IX_DOCUMENTOD_TD_CODZET")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Docref, e.Fecdoc }, "IX_DOCUMENTOD_TD_DOCREF_FECDOC1")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Docref, e.Fecdoc }, "IX_DOCUMENTOD_TD_DOCREF_FECDOC2")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Fecdoc }, "IX_DOCUMENTOD_TD_FECDOC1")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Fecdoc }, "IX_DOCUMENTOD_TD_FECDOC10")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Fecdoc }, "IX_DOCUMENTOD_TD_FECDOC11")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Fecdoc }, "IX_DOCUMENTOD_TD_FECDOC12")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Fecdoc }, "IX_DOCUMENTOD_TD_FECDOC2")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Fecdoc }, "IX_DOCUMENTOD_TD_FECDOC3")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Fecdoc }, "IX_DOCUMENTOD_TD_FECDOC4")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Fecdoc }, "IX_DOCUMENTOD_TD_FECDOC5")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Fecdoc }, "IX_DOCUMENTOD_TD_FECDOC6")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Fecdoc }, "IX_DOCUMENTOD_TD_FECDOC7")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Fecdoc }, "IX_DOCUMENTOD_TD_FECDOC8")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Fecdoc }, "IX_DOCUMENTOD_TD_FECDOC9")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Fecdoc, e.Codbod }, "IX_DOCUMENTOD_TD_FECDOC_CODBOD1")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Fecdoc, e.Codpro }, "IX_DOCUMENTOD_TD_FECDOC_CODPRO2")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Fecdoc, e.Codpro }, "IX_DOCUMENTOD_TD_FECDOC_CODPRO3")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Fecdoc, e.Docref }, "IX_DOCUMENTOD_TD_FECDOC_DOCREF1")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Fecdoc, e.Docref }, "IX_DOCUMENTOD_TD_FECDOC_DOCREF2")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Secref }, "IX_DOCUMENTOD_TD_SECREF1")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Td, e.Tdref, e.Fecdoc }, "IX_DOCUMENTOD_TD_TDREF_FECDOC")
                    .HasFillFactor((byte)100);

                entity.Property(e => e.Cantce).HasDefaultValueSql("(0)");

                entity.Property(e => e.Cantex).HasDefaultValueSql("(0)");

                entity.Property(e => e.Codbod)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Codlocal)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Codpro).IsUnicode(false);

                entity.Property(e => e.Codzet).IsUnicode(false);

                entity.Property(e => e.Despacha)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Docref).IsUnicode(false);

                entity.Property(e => e.Entregada)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Numdoc).IsUnicode(false);

                entity.Property(e => e.Responsable)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Td).IsUnicode(false);

                entity.Property(e => e.Tdref).IsUnicode(false);
            });

            modelBuilder.Entity<Faccli>(entity =>
            {
                entity.Property(e => e.Codcli).IsUnicode(false);

                entity.Property(e => e.Ciudad)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Com1).IsUnicode(false);

                entity.Property(e => e.Com2).IsUnicode(false);

                entity.Property(e => e.Com3).IsUnicode(false);

                entity.Property(e => e.Comuna)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.CondPag).IsUnicode(false);

                entity.Property(e => e.Dg).IsUnicode(false);

                entity.Property(e => e.Dg2).IsUnicode(false);

                entity.Property(e => e.Direc)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Email).IsUnicode(false);

                entity.Property(e => e.Fax).IsUnicode(false);

                entity.Property(e => e.Fono).IsUnicode(false);

                entity.Property(e => e.Giro).IsUnicode(false);

                entity.Property(e => e.LisPre).IsUnicode(false);

                entity.Property(e => e.Modopago).IsUnicode(false);

                entity.Property(e => e.Nombre)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Pais).IsUnicode(false);

                entity.Property(e => e.Rut).IsUnicode(false);

                entity.Property(e => e.RutFac).IsUnicode(false);

                entity.Property(e => e.Sigla).IsUnicode(false);

                entity.Property(e => e.Tipo).IsUnicode(false);

                entity.Property(e => e.Ubic1).IsUnicode(false);

                entity.Property(e => e.Ubic2).IsUnicode(false);

                entity.Property(e => e.Ubic3).IsUnicode(false);

                entity.Property(e => e.Vend).IsUnicode(false);

                entity.Property(e => e.Vigencia).IsUnicode(false);

                entity.Property(e => e.Zona).IsUnicode(false);
            });

            modelBuilder.Entity<Factab>(entity =>
            {
                entity.Property(e => e.Atrib1).IsUnicode(false);

                entity.Property(e => e.Atrib2).IsUnicode(false);

                entity.Property(e => e.Atrib3).IsUnicode(false);

                entity.Property(e => e.Atrib4).IsUnicode(false);

                entity.Property(e => e.Codigo).IsUnicode(false);

                entity.Property(e => e.Descrip).IsUnicode(false);

                entity.Property(e => e.Empresa).IsUnicode(false);

                entity.Property(e => e.Tipo).IsUnicode(false);
            });

            modelBuilder.Entity<Stoart>(entity =>
            {
                entity.HasIndex(e => e.Cup, "IX_STOART_CUP")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => e.Kopr, "IX_STOART_KOPR")
                    .HasFillFactor((byte)100);

                entity.HasIndex(e => new { e.Codpro, e.Familia, e.Subfam, e.Tipo, e.Subtipo }, "vd")
                    .HasFillFactor((byte)50);

                entity.Property(e => e.Codpro).IsUnicode(false);

                entity.Property(e => e.Bmp).IsUnicode(false);

                entity.Property(e => e.Codint).IsUnicode(false);

                entity.Property(e => e.Com1).IsUnicode(false);

                entity.Property(e => e.Composicion).IsUnicode(false);

                entity.Property(e => e.Descri).IsUnicode(false);

                entity.Property(e => e.Estado)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Familia).IsUnicode(false);

                entity.Property(e => e.Impuesto)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Kopr)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Moncom)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Monfac)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Proced)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Subfam).IsUnicode(false);

                entity.Property(e => e.Subtipo).IsUnicode(false);

                entity.Property(e => e.Tipo).IsUnicode(false);

                entity.Property(e => e.Tipoprod)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Ubic).IsUnicode(false);

                entity.Property(e => e.Unimed).IsUnicode(false);

                entity.Property(e => e.Unimed2).IsUnicode(false);
            });

            modelBuilder.Entity<Tipodocumento>(entity =>
            {
                entity.HasNoKey();

                entity.Property(e => e.Clase)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Codidoc).IsUnicode(false);

                entity.Property(e => e.Cuenta)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Impuesto)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Modulo).IsUnicode(false);

                entity.Property(e => e.Namedocumento).IsUnicode(false);

                entity.Property(e => e.Sistema)
                    .IsUnicode(false)
                    .IsFixedLength(true);

                entity.Property(e => e.Tipodoc).IsUnicode(false);
            });

            modelBuilder.Entity<DocumentoOb>(entity =>
            {
                entity.Property(e => e.Idbultos).IsUnicode(false);
            });

            modelBuilder.Entity<Parametro>(entity =>
            {
                entity.Property(e => e.Dgempresa)
                    .IsUnicode(false)
                    .IsFixedLength(true);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}