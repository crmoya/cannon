﻿namespace Integracion.Models
{
    public class Shipping
    {
        public Address Address { get; set; }
    }
}
