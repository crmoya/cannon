﻿using System;
namespace Integracion.Models
{
    public class SelectItem
    {
        public string Value { get; set; }
        public string Text { get; set; }
    }
}
