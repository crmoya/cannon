﻿using System;

namespace Integracion.Models
{
    public class VentaProducto
    {
        public string CodigoProducto { get; set; }
        public string NombreProducto { get; set; }
        public string OC { get; set; }
        public string NV { get; set; }
        public string Familia { get; set; }
        public string Subfamilia { get; set; }
        public double? Unidades { get; set; }
        public double? ValorUnitario { get; set; }
        public double? Total { get; set; }
        public DateTime? Fecha { get; set; }
        public string BoletaOSRF { get; set; }
        public string Boleta { get; internal set; }
        public string Srf { get; internal set; }
    }
}
