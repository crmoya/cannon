﻿namespace Integracion.Models
{
    public class PaymentAdditionalInfo
    {
        public string Key { get; set; }
        public string Value { get; set; }
    }
}