namespace Integracion.Models{ 

    public class LoginModel{ 
        public string Usuario { get; set; }
        public string Clave { get; set; }

    }

}