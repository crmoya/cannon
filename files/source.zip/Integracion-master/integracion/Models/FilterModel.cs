﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using Integracion.Validators;

namespace Integracion.Models
{
    public class FilterModel
    {
        [MinFechaValidator]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}")]
        [DisplayName("Fecha Inicio")]
        public DateTime? FechaInicio { get; set; }

        [MinFechaValidator]
        [DisplayFormat(DataFormatString = "{0:dd-MM-yyyy}")]
        [DisplayName("Fecha Fin")]
        public DateTime? FechaFin { get; set; }

        [DisplayName("Con Excepciones")]
        public string Excepcion { get; set; }

        [DisplayName("Tipo Evento")]
        public string TipoLog { get; set; }
        public string Procesadas { get; set; }

    }
}
