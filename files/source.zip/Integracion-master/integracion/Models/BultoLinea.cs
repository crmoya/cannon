﻿namespace Integracion.Models
{
    public class BultoLinea
    {
        public int LineaId { get; set; }
        public string Bultos { get; set; }
    }
}
