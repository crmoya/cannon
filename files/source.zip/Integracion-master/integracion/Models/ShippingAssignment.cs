﻿namespace Integracion.Models
{
    public class ShippingAssignment
    {
        public Shipping Shipping { get; set; }
    }
}
