﻿namespace Integracion.Models
{
    public class ProductOrder
    {
        public double Price { get; set; }
        public double Row_Total { get; set; }
        public double Qty_Ordered { get; set; }
        public string Sku { get; set; }
        public string Name { get; set; }
        public int Order_Id { get; set; }
    }
}
