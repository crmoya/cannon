﻿using Integracion.Entities;
using System;
using System.Collections.Generic;

namespace Integracion.Models
{
    public class NotaVenta
    {

        public int IdDocumento { get; set; }
        public string NumDocumento { get; set; }
        public DateTime? FechaDocumento { get; set; }
        public string OC { get; set; }
        public DateTime? FechaOC { get; set; }
        public string RutCliente { get; set; }
        public string NombreCliente { get; set; }
        public int MontoVenta { get; set; }
        public int CostoDespacho { get; set; }
        public DateTime? FechaEntrega { get; set; }
        public DateTime? FechaCreacion { get; set; }
        public List<LineaNotaVenta> Lineas { get; set; }
        public List<ExcepcionOrdenProcesada> Excepciones { get; set; }
        public Boleta Boleta { get; set; }
        public Srf Srf { get; set; }
        public Dsm Dsm { get; set; }
        public OrdenProcesada OrdenCompra { get; set; }
        public DocumentoPicking Picking { get; set; }

    }
}
