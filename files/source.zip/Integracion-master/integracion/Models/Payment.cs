﻿using System.Collections.Generic;

namespace Integracion.Models
{
    public class Payment
    {
        public string Method { get; set; }

        public string FormaPago 
        { 
            get
            {
                if(Method.ToLower().Contains("mercadopago"))
                {
                    return Shared.BANCO_MERCADOPAGO;
                }
                else if (Method.ToLower().Contains("webpay"))
                {
                    return Shared.BANCO_WEBPAY;
                }
                return "OTRA";
            }
        }
    }
}
