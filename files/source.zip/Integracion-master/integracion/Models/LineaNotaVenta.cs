﻿namespace Integracion.Models
{
    public class LineaNotaVenta
    {
        public int Secuencia { get; set; }
        public string CodigoProducto { get; set; }
        public string DescripcionProducto { get; set; }
        public int CostoUnitario { get; set; }
        public int PrecioVenta { get; set; }
        public int Cantidad { get; set; }
        public int TotalLinea { get; set; }
        public int DocDId { get; set; }
        public string Bultos { get; set; }
    }
}
