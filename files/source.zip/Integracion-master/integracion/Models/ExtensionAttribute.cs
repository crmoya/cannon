﻿using System.Collections.Generic;

namespace Integracion.Models
{
    public class ExtensionAttribute
    {
        public string Rut { get; set; }
        public List<ShippingAssignment> Shipping_Assignments { get; set; }
        public List<PaymentAdditionalInfo> Payment_Additional_Info { get; set; }
    }
}
