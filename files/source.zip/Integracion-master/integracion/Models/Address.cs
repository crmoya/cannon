﻿using System.Collections.Generic;

namespace Integracion.Models
{
    public class Address
    {
        public string Address_Type { get; set; }
        public string City { get; set; }
        public string Country_Id { get; set; }
        public string Region { get; set; }
        public string Region_Code { get; set; }
        public List<string> Street { get; set; }
        public string Telephone { get; set; }        
        public string Direccion {
            get {
                var _direccion = "";
                foreach(var street in Street)
                {
                    _direccion += street + " ";
                }
                return _direccion;
            }
        }
    }
}
