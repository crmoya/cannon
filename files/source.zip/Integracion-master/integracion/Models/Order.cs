﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Integracion.Models
{
    public class Order
    {
        [Required]
        public string State { get; set; }
        public string Status { get; set; }
        public string Increment_Id { get; set; }
        public int Entity_Id { get; set; }
        public DateTime Created_At { get; set; }
        public double? Subtotal_Incl_Tax { get; set; }
        public double? Total_Due { get; set; }
        public double? Shipping_Amount { get; set; }
        public int Customer_Is_Guest { get; set; }
        public int Customer_Id { get; set; }
        public string Customer_Email { get; set; }
        public string Customer_Firstname { get; set; }
        public string Customer_Lastname { get; set; }
        public ExtensionAttribute Extension_Attributes { get; set; }
        public Customer Customer { get; set; }
        public List<ProductOrder> Items { get; set; }
        public Payment Payment { get; set; }
    }
}
