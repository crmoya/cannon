﻿namespace Integracion.Models
{
    public class StockItem
    {
        public int qty { get; set; }
        public bool is_in_stock { get; set; }
    }
}
