﻿namespace Integracion.Models
{
    public class LineaDsm
    {
        public int? IdLinea { get; set; }
        public string CodZeta { get; set; }
        public double? Cantidad { get; set; }
        public string NumeroDocumento { get; set; }
        public string CodPro { get; set; }
        public double? CifUni { get; set; }
        public double? VtaUni { get; set; }
        public double? Impuesto { get; set; }
    }
}
