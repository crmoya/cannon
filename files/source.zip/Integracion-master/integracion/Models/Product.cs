﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Integracion.Models
{
    public class Product
    {
        [Required]
        public int Item_Id { get; set; }
        public bool Is_In_Stock { get; set; }
        public int Qty { get; set; }
    }
}
