﻿using Integracion.Entities;

namespace Integracion.Models
{
    public class OrdenDoc
    {
        public OrdenDocumento OrdenDocumento { get; set; }
        public Boleta Boleta { get; set; }
        public Srf Srf { get; set; }
    }
}
