﻿namespace Integracion.Models
{
    public class StockItemWrapper
    {
        public StockItem stockItem { get; set; }
    }
}
