﻿
using Newtonsoft.Json.Linq;

namespace Integracion.Models
{
    public class MultiResponse
    {
        public JArray items { get; set; }
        public object search_criteria { get; set; }
        public object total_count { get; set; }
    }
}
