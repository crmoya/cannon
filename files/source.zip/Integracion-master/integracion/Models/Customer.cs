﻿using System;
using System.Collections.Generic;

namespace Integracion.Models
{
    public class Customer
    {
        public int Id { get; set; }
        public string Email { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public Address Address { get; set; }

        public string CompleteRut { get; set; }

        #region CustomProperties

        public string Direccion 
        {
            get
            {
                return Address.Direccion;
            }
        }

        public string Ciudad
        {
            get {
                return Address.City;
            }
        }

        public string Region
        {
            get
            {
                return Address.Region;
            }
        }

        public string Fono
        {
            get
            {
                return Address.Telephone;
            }
        }

        public string Rut { 
            get {
                string _rut = "";
                try
                {
                    string rut = CompleteRut.ToUpper();
                    rut = rut.Replace(".", "");
                    var rutArr = rut.Split("-");
                    if(rutArr.Length == 2)
                    {
                        _rut = rutArr[0];
                    }
                    else
                    {
                        _rut = rut;
                    }
                }
                catch (Exception)
                {
                }
                return _rut;
            } 
        }

        public string DV
        {
            get
            {
                string dv = null;
                try
                {
                    string rut = CompleteRut.ToUpper();
                    rut = rut.Replace(".", "");
                    var rutArr = rut.Split("-");
                    if (rutArr.Length == 2)
                    {
                        dv = rutArr[1];
                    }
                }
                catch (Exception)
                {
                }
                return dv;
            }
        }
        #endregion



    }

}
