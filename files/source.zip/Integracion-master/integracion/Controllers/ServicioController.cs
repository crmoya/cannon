﻿using Integracion.Data;
using Integracion.Entities;
using Integracion.Extensions;
using Integracion.Models;
using Integracion.Tasks;
using Integracion.Utils;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Integracion.Controllers
{
    public class ServicioController : Controller
    {
        private readonly AppDbContext _context;
        private readonly Logger _logger;

        public ServicioController(AppDbContext context)
        {
            _context = context;
            _logger = new Logger(context);
        }
        public async Task<IActionResult> ForzarCarga()
        {
            var recurringTask = new RecurringTask(_context);
            var ok = recurringTask.CheckRepairedExceptions();
            if (!ok)
            {
                return Json(new { status = "ERROR", mensaje = "Error en el proceso de carga forzada, por favor reintente." });
            }
            return Json(new { status = "SUCCESS", mensaje = "Proceso de carga forzada de datos finalizado correctamente." });
        }

    }
}
