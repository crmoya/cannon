﻿using Integracion.Data;
using Integracion.Entities;
using Integracion.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Integracion.Controllers
{
    public class ReportController : Controller
    {
        private readonly AppDbContext _context;

        public ReportController(AppDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Caja()
        {
            var fechaInicio = DateTime.Today.AddDays(-7);
            var ordenesNotas = await _context.orden_documento
                                            .Include(od => od.Documento)
                                            .Include(od => od.Orden)
                                            .Where(od =>
                                                    od.Documento.Fecdoc >= fechaInicio &&
                                                    od.Documento.Td == "NVV")
                                            .ToListAsync();

            var ordenesDocumentos =   (from o in ordenesNotas
                                        //left join boletas
                                        join b in _context.boleta on o.DocumentoId equals b.NotaVentaId into bo
                                        from boleta in bo.DefaultIfEmpty()
                                        //left join srf
                                        join s in _context.srf on o.DocumentoId equals s.NotaVentaId into sr
                                        from srf in sr.DefaultIfEmpty()
                                        select new OrdenDoc
                                        {
                                            OrdenDocumento = o,
                                            Boleta = boleta,
                                            Srf = srf,
                                        })
                                        .OrderByDescending(doc => doc.OrdenDocumento.Documento.Fecdoc)
                                        .ToList();

            var datos = new List<List<string>>();
            foreach (var ordenDocumento in ordenesDocumentos)
            {
                var cliente = _context.cliente.FirstOrDefault(c => c.Rut == ordenDocumento.OrdenDocumento.Documento.Idlegal);
                var clienteStr = cliente != null ? cliente.Rut + "-" + cliente.Dg : "";
                var ciudad = cliente != null ? cliente.Ciudad : "";
                var total = ordenDocumento.OrdenDocumento.Documento.Totdoc;
                var despacho = ordenDocumento.OrdenDocumento.Orden.Despacho;

                var pago = _context.pago_documento
                                    .Include(pd => pd.Pago)
                                    .FirstOrDefault(pd => pd.DocumentoId == ordenDocumento.OrdenDocumento.DocumentoId);
                var medioPago = pago.Pago.Banco;

                var boletaOSrf = "";
                if(ordenDocumento.Boleta != null)
                {
                    boletaOSrf = ordenDocumento.Boleta.NumDocBoleta;
                }
                if (ordenDocumento.Srf != null)
                {
                    boletaOSrf = ordenDocumento.Srf.NumDocSrf;
                }
                datos.Add(new List<string> {
                    ordenDocumento.OrdenDocumento.Documento.Numdoc,
                    ordenDocumento.OrdenDocumento.Documento.Numdoc,
                    boletaOSrf,
                    String.Format("{0:dd-MM-yyyy}",ordenDocumento.OrdenDocumento.Documento.Fecdoc),
                    clienteStr,
                    ciudad,
                    medioPago,
                    "$" + String.Format("{0:N0}",total),
                    "$" + String.Format("{0:N0}",despacho),
                });
            }
            ViewData["Datos"] = datos;
            var filter = new FilterModel { FechaInicio = fechaInicio };
            return View(filter);
        }

        [HttpPost]
        public async Task<IActionResult> Caja(FilterModel filterModel)
        {
            var datos = new List<List<string>>();
            if (ModelState.IsValid)
            {
                var fechaInicio = filterModel.FechaInicio;
                var fechaFin = filterModel.FechaFin;

                if (fechaFin != null)
                {
                    var tempFecha = (DateTime)fechaFin;
                    fechaFin = tempFecha.AddDays(1);
                }
                var ordenesNotas = new List<OrdenDocumento>();
                if (fechaInicio != null && fechaFin != null)
                {
                    ordenesNotas = await _context.orden_documento
                                                 .Include(od => od.Documento)
                                                 .Include(od => od.Orden)
                                                 .Where(od =>
                                                         od.Documento.Fecdoc >= fechaInicio &&
                                                         od.Documento.Fecdoc < fechaFin &&
                                                         od.Documento.Td == "NVV")
                                                 .ToListAsync();
                }
                if (fechaInicio == null && fechaFin != null)
                {
                    ordenesNotas = await _context.orden_documento
                                                 .Include(od => od.Documento)
                                                 .Include(od => od.Orden)
                                                 .Where(od =>
                                                         od.Documento.Fecdoc < fechaFin &&
                                                         od.Documento.Td == "NVV")
                                                 .ToListAsync();
                }
                if (fechaInicio != null && fechaFin == null)
                {
                    ordenesNotas = await _context.orden_documento
                                                 .Include(od => od.Documento)
                                                 .Include(od => od.Orden)
                                                 .Where(od =>
                                                         od.Documento.Fecdoc >= fechaInicio &&
                                                         od.Documento.Td == "NVV")
                                                 .ToListAsync();
                }
                if (fechaInicio == null && fechaFin == null)
                {
                    ordenesNotas = await _context.orden_documento
                                                 .Include(od => od.Documento)
                                                 .Include(od => od.Orden)
                                                 .Where(od =>
                                                         od.Documento.Td == "NVV")
                                                 .ToListAsync();
                }

                var ordenesDocumentos = (from o in ordenesNotas
                                             //left join boletas
                                         join b in _context.boleta on o.DocumentoId equals b.NotaVentaId into bo
                                         from boleta in bo.DefaultIfEmpty()
                                             //left join srf
                                         join s in _context.srf on o.DocumentoId equals s.NotaVentaId into sr
                                         from srf in sr.DefaultIfEmpty()
                                         select new OrdenDoc
                                         {
                                             OrdenDocumento = o,
                                             Boleta = boleta,
                                             Srf = srf,
                                         })
                                       .OrderByDescending(doc => doc.OrdenDocumento.Documento.Fecdoc)
                                       .ToList();

                foreach (var ordenDocumento in ordenesDocumentos)
                {
                    var cliente = _context.cliente.FirstOrDefault(c => c.Rut == ordenDocumento.OrdenDocumento.Documento.Idlegal);
                    var clienteStr = cliente != null ? cliente.Rut + "-" + cliente.Dg : "";
                    var ciudad = cliente != null ? cliente.Ciudad : "";
                    var total = ordenDocumento.OrdenDocumento.Documento.Totdoc;
                    var despacho = ordenDocumento.OrdenDocumento.Orden.Despacho;
                    var pago = _context.pago_documento
                                        .Include(pd => pd.Pago)
                                        .FirstOrDefault(pd => pd.DocumentoId == ordenDocumento.OrdenDocumento.DocumentoId);
                    var medioPago = pago.Pago.Banco;

                    var boletaOSrf = "";
                    if (ordenDocumento.Boleta != null)
                    {
                        boletaOSrf = ordenDocumento.Boleta.NumDocBoleta;
                    }
                    if (ordenDocumento.Srf != null)
                    {
                        boletaOSrf = ordenDocumento.Srf.NumDocSrf;
                    }
                    datos.Add(new List<string> {
                    ordenDocumento.OrdenDocumento.Documento.Numdoc,
                    ordenDocumento.OrdenDocumento.Documento.Numdoc,
                    boletaOSrf,
                    String.Format("{0:dd-MM-yyyy}",ordenDocumento.OrdenDocumento.Documento.Fecdoc),
                    clienteStr,
                    ciudad,
                    medioPago,
                    "$" + String.Format("{0:N0}",total),
                    "$" + String.Format("{0:N0}",despacho),
                });
                }
            }
                
            ViewData["Datos"] = datos;
            return View(filterModel);
        }

        public async Task<IActionResult> VentasCliente()
        {
            var fechaInicio = DateTime.Today.AddDays(-7);
            var ordenesNotas = await _context.orden_documento
                                            .Include(od => od.Documento)
                                            .Include(od => od.Orden)
                                            .Where(od =>
                                                    od.Documento.Fecdoc >= fechaInicio &&
                                                    od.Documento.Td == "NVV")
                                            .ToListAsync();

            var datos = new List<List<string>>();
            foreach (var ordenNota in ordenesNotas)
            {
                var cliente = _context.cliente.FirstOrDefault(c => c.Rut == ordenNota.Documento.Idlegal);
                var rut = cliente != null ? cliente.Rut + "-" + cliente.Dg : "";
                var clienteNom = cliente != null ? cliente.Nombre : "";
                var ciudad = cliente != null ? cliente.Ciudad : "";
                var total = ordenNota.Documento.Totdoc;
                var despacho = ordenNota.Orden.Despacho;

                datos.Add(new List<string> {
                    ordenNota.Documento.Numdoc,
                    ordenNota.Documento.Numdoc,
                    String.Format("{0:dd-MM-yyyy}",ordenNota.Documento.Fecdoc),
                    rut,
                    clienteNom,
                    ciudad,
                    "$" + String.Format("{0:N0}",total),
                    "$" + String.Format("{0:N0}",despacho),
                });
            }
            ViewData["Datos"] = datos;
            var filter = new FilterModel { FechaInicio = fechaInicio };
            return View(filter);
        }

        [HttpPost]
        public async Task<IActionResult> VentasCliente(FilterModel filterModel)
        {
            var datos = new List<List<string>>();
            if (ModelState.IsValid)
            {
                var fechaInicio = filterModel.FechaInicio;
                var fechaFin = filterModel.FechaFin;

                if (fechaFin != null)
                {
                    var tempFecha = (DateTime)fechaFin;
                    fechaFin = tempFecha.AddDays(1);
                }
                var ordenesNotas = new List<OrdenDocumento>();
                if (fechaInicio != null && fechaFin != null)
                {
                    ordenesNotas = await _context.orden_documento
                                                .Include(od => od.Documento)
                                                .Include(od => od.Orden)
                                                .Where(od =>
                                                        od.Documento.Fecdoc >= fechaInicio &&
                                                        od.Documento.Fecdoc < fechaFin &&
                                                        od.Documento.Td == "NVV")
                                                .ToListAsync();
                }
                if (fechaInicio == null && fechaFin != null)
                {
                    ordenesNotas = await _context.orden_documento
                                                .Include(od => od.Documento)
                                                .Include(od => od.Orden)
                                                .Where(od =>
                                                        od.Documento.Fecdoc < fechaFin &&
                                                        od.Documento.Td == "NVV")
                                                .ToListAsync();
                }
                if (fechaInicio != null && fechaFin == null)
                {
                    ordenesNotas = await _context.orden_documento
                                                .Include(od => od.Documento)
                                                .Include(od => od.Orden)
                                                .Where(od =>
                                                        od.Documento.Fecdoc >= fechaInicio &&
                                                        od.Documento.Td == "NVV")
                                                .ToListAsync();
                }
                if (fechaInicio == null && fechaFin == null)
                {
                    ordenesNotas = await _context.orden_documento
                                                .Include(od => od.Documento)
                                                .Include(od => od.Orden)
                                                .Where(od =>
                                                        od.Documento.Td == "NVV")
                                                .ToListAsync();
                }

                foreach (var ordenNota in ordenesNotas)
                {
                    var cliente = _context.cliente.FirstOrDefault(c => c.Rut == ordenNota.Documento.Idlegal);
                    var rut = cliente != null ? cliente.Rut + "-" + cliente.Dg : "";
                    var clienteNom = cliente != null ? cliente.Nombre : "";
                    var ciudad = cliente != null ? cliente.Ciudad : "";
                    var total = ordenNota.Documento.Totdoc;
                    var despacho = ordenNota.Orden.Despacho;

                    datos.Add(new List<string> {
                        ordenNota.Documento.Numdoc,
                        ordenNota.Documento.Numdoc,
                        String.Format("{0:dd-MM-yyyy}",ordenNota.Documento.Fecdoc),
                        rut,
                        clienteNom,
                        ciudad,
                        "$" + String.Format("{0:N0}",total),
                        "$" + String.Format("{0:N0}",despacho),
                    });
                }
            }
            
            ViewData["Datos"] = datos;
            return View(filterModel);
        }

        public async Task<IActionResult> VentasProducto()
        {
            var fechaInicio = DateTime.Today.AddDays(-7);
            var ventas = (from documentoDetalle in _context.documento_detalle
                          join notaVenta in _context.documento on documentoDetalle.Iddocto equals notaVenta.Iddocto
                          join ordenDocumento in _context.orden_documento on notaVenta.Iddocto equals ordenDocumento.DocumentoId
                          join ordenProcesada in _context.orden_procesada on ordenDocumento.OrdenId equals ordenProcesada.Id
                          join producto in _context.stock_articulo on documentoDetalle.Codpro equals producto.Codpro
                          //left join boletas
                          join b in _context.boleta on ordenDocumento.DocumentoId equals b.NotaVentaId into bo
                          from boleta in bo.DefaultIfEmpty()
                              //left join srf
                          join s in _context.srf on ordenDocumento.DocumentoId equals s.NotaVentaId into sr
                          from srf in sr.DefaultIfEmpty()
                          where notaVenta.Td == "NVV" && notaVenta.Fecdoc >= fechaInicio
                          select new VentaProducto
                          {
                              CodigoProducto = documentoDetalle.Codpro,
                              NombreProducto = producto.Descri,
                              Familia = producto.Familia,
                              Subfamilia = producto.Subfam,
                              Fecha = notaVenta.Fecdoc,
                              NV = notaVenta.Numdoc,
                              OC = ordenProcesada.OrdenId,
                              Total = documentoDetalle.Vtauni * documentoDetalle.Cant,
                              Unidades = documentoDetalle.Cant,
                              ValorUnitario = documentoDetalle.Vtauni,
                              Boleta = boleta != null ? boleta.NumDocBoleta : "",
                              Srf = srf != null ? srf.NumDocSrf : "",
                          }).ToList();
            var datos = new List<List<string>>();
            foreach (var venta in ventas)
            {
                var boletaOSrf = "";
                if(venta.Boleta != "")
                {
                    boletaOSrf = venta.Boleta;
                }
                if (venta.Srf != "")
                {
                    boletaOSrf = venta.Srf;
                }
                datos.Add(new List<string> {
                    venta.NV,
                    venta.NV,
                    venta.OC,
                    venta.CodigoProducto,
                    venta.NombreProducto,
                    venta.Familia,
                    venta.Subfamilia,
                    String.Format("{0:N0}",venta.Unidades),
                    "$" + String.Format("{0:N0}",venta.ValorUnitario),
                    "$" + String.Format("{0:N0}",venta.Unidades * venta.ValorUnitario),
                    String.Format("{0:dd-MM-yyyy}",venta.Fecha),
                    boletaOSrf,
                });
            }

            ViewData["Datos"] = datos;
            var filterModel = new FilterModel { FechaInicio = fechaInicio };
            return View(filterModel);
        }

        [HttpPost]
        public async Task<IActionResult> VentasProducto(FilterModel filterModel)
        {
            var datos = new List<List<string>>();
            if (ModelState.IsValid)
            {
                var fechaInicio = filterModel.FechaInicio;
                var fechaFin = filterModel.FechaFin;
                if (fechaFin != null)
                {
                    var tempFecha = (DateTime)fechaFin;
                    fechaFin = tempFecha.AddDays(1);
                }
                var ventas = new List<VentaProducto>();
                if (fechaInicio != null && fechaFin != null)
                {
                    ventas = (from documentoDetalle in _context.documento_detalle
                              join notaVenta in _context.documento on documentoDetalle.Iddocto equals notaVenta.Iddocto
                              join ordenDocumento in _context.orden_documento on notaVenta.Iddocto equals ordenDocumento.DocumentoId
                              join ordenProcesada in _context.orden_procesada on ordenDocumento.OrdenId equals ordenProcesada.Id
                              join producto in _context.stock_articulo on documentoDetalle.Codpro equals producto.Codpro
                              //left join boletas
                              join b in _context.boleta on ordenDocumento.DocumentoId equals b.NotaVentaId into bo
                              from boleta in bo.DefaultIfEmpty()
                                  //left join srf
                              join s in _context.srf on ordenDocumento.DocumentoId equals s.NotaVentaId into sr
                              from srf in sr.DefaultIfEmpty()
                              where notaVenta.Td == "NVV" && notaVenta.Fecdoc >= fechaInicio && notaVenta.Fecdoc < fechaFin
                              select new VentaProducto
                              {
                                  CodigoProducto = documentoDetalle.Codpro,
                                  NombreProducto = producto.Descri,
                                  Familia = producto.Familia,
                                  Subfamilia = producto.Subfam,
                                  Fecha = notaVenta.Fecdoc,
                                  NV = notaVenta.Numdoc,
                                  OC = ordenProcesada.OrdenId,
                                  Total = documentoDetalle.Vtauni * documentoDetalle.Cant,
                                  Unidades = documentoDetalle.Cant,
                                  ValorUnitario = documentoDetalle.Vtauni,
                                  Boleta = boleta != null ? boleta.NumDocBoleta : "",
                                  Srf = srf != null ? srf.NumDocSrf : "",
                              }).ToList();
                }
                if (fechaInicio == null && fechaFin != null)
                {
                    ventas = (from documentoDetalle in _context.documento_detalle
                              join notaVenta in _context.documento on documentoDetalle.Iddocto equals notaVenta.Iddocto
                              join ordenDocumento in _context.orden_documento on notaVenta.Iddocto equals ordenDocumento.DocumentoId
                              join ordenProcesada in _context.orden_procesada on ordenDocumento.OrdenId equals ordenProcesada.Id
                              join producto in _context.stock_articulo on documentoDetalle.Codpro equals producto.Codpro
                              //left join boletas
                              join b in _context.boleta on ordenDocumento.DocumentoId equals b.NotaVentaId into bo
                              from boleta in bo.DefaultIfEmpty()
                                  //left join srf
                              join s in _context.srf on ordenDocumento.DocumentoId equals s.NotaVentaId into sr
                              from srf in sr.DefaultIfEmpty()
                              where notaVenta.Td == "NVV" && notaVenta.Fecdoc < fechaFin
                              select new VentaProducto
                              {
                                  CodigoProducto = documentoDetalle.Codpro,
                                  NombreProducto = producto.Descri,
                                  Familia = producto.Familia,
                                  Subfamilia = producto.Subfam,
                                  Fecha = notaVenta.Fecdoc,
                                  NV = notaVenta.Numdoc,
                                  OC = ordenProcesada.OrdenId,
                                  Total = documentoDetalle.Vtauni * documentoDetalle.Cant,
                                  Unidades = documentoDetalle.Cant,
                                  ValorUnitario = documentoDetalle.Vtauni,
                                  Boleta = boleta != null ? boleta.NumDocBoleta : "",
                                  Srf = srf != null ? srf.NumDocSrf : "",
                              }).ToList();
                }
                if (fechaInicio != null && fechaFin == null)
                {
                    ventas = (from documentoDetalle in _context.documento_detalle
                              join notaVenta in _context.documento on documentoDetalle.Iddocto equals notaVenta.Iddocto
                              join ordenDocumento in _context.orden_documento on notaVenta.Iddocto equals ordenDocumento.DocumentoId
                              join ordenProcesada in _context.orden_procesada on ordenDocumento.OrdenId equals ordenProcesada.Id
                              join producto in _context.stock_articulo on documentoDetalle.Codpro equals producto.Codpro
                              //left join boletas
                              join b in _context.boleta on ordenDocumento.DocumentoId equals b.NotaVentaId into bo
                              from boleta in bo.DefaultIfEmpty()
                                  //left join srf
                              join s in _context.srf on ordenDocumento.DocumentoId equals s.NotaVentaId into sr
                              from srf in sr.DefaultIfEmpty()
                              where notaVenta.Td == "NVV" && notaVenta.Fecdoc >= fechaInicio
                              select new VentaProducto
                              {
                                  CodigoProducto = documentoDetalle.Codpro,
                                  NombreProducto = producto.Descri,
                                  Familia = producto.Familia,
                                  Subfamilia = producto.Subfam,
                                  Fecha = notaVenta.Fecdoc,
                                  NV = notaVenta.Numdoc,
                                  OC = ordenProcesada.OrdenId,
                                  Total = documentoDetalle.Vtauni * documentoDetalle.Cant,
                                  Unidades = documentoDetalle.Cant,
                                  ValorUnitario = documentoDetalle.Vtauni,
                                  Boleta = boleta != null ? boleta.NumDocBoleta : "",
                                  Srf = srf != null ? srf.NumDocSrf : "",
                              }).ToList();
                }
                if (fechaInicio == null && fechaFin == null)
                {
                    ventas = (from documentoDetalle in _context.documento_detalle
                              join notaVenta in _context.documento on documentoDetalle.Iddocto equals notaVenta.Iddocto
                              join ordenDocumento in _context.orden_documento on notaVenta.Iddocto equals ordenDocumento.DocumentoId
                              join ordenProcesada in _context.orden_procesada on ordenDocumento.OrdenId equals ordenProcesada.Id
                              join producto in _context.stock_articulo on documentoDetalle.Codpro equals producto.Codpro
                              //left join boletas
                              join b in _context.boleta on ordenDocumento.DocumentoId equals b.NotaVentaId into bo
                              from boleta in bo.DefaultIfEmpty()
                                  //left join srf
                              join s in _context.srf on ordenDocumento.DocumentoId equals s.NotaVentaId into sr
                              from srf in sr.DefaultIfEmpty()
                              select new VentaProducto
                              {
                                  CodigoProducto = documentoDetalle.Codpro,
                                  NombreProducto = producto.Descri,
                                  Familia = producto.Familia,
                                  Subfamilia = producto.Subfam,
                                  Fecha = notaVenta.Fecdoc,
                                  NV = notaVenta.Numdoc,
                                  OC = ordenProcesada.OrdenId,
                                  Total = documentoDetalle.Vtauni * documentoDetalle.Cant,
                                  Unidades = documentoDetalle.Cant,
                                  ValorUnitario = documentoDetalle.Vtauni,
                                  Boleta = boleta != null ? boleta.NumDocBoleta : "",
                                  Srf = srf != null ? srf.NumDocSrf : "",
                              }).ToList();
                }

                foreach (var venta in ventas)
                {
                    var boletaOSrf = "";
                    if (venta.Boleta != "")
                    {
                        boletaOSrf = venta.Boleta;
                    }
                    if (venta.Srf != "")
                    {
                        boletaOSrf = venta.Srf;
                    }
                    datos.Add(new List<string> {
                        venta.NV,
                        venta.NV,
                        venta.OC,
                        venta.CodigoProducto,
                        venta.NombreProducto,
                        venta.Familia,
                        venta.Subfamilia,
                        String.Format("{0:N0}",venta.Unidades),
                        "$" + String.Format("{0:N0}",venta.ValorUnitario),
                        "$" + String.Format("{0:N0}",venta.Unidades * venta.ValorUnitario),
                        String.Format("{0:dd-MM-yyyy}",venta.Fecha),
                        boletaOSrf,
                    });
                }
            }            
            ViewData["Datos"] = datos;
            return View(filterModel);
        }

    }
}
