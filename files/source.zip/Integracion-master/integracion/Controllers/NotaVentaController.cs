﻿using Integracion.Data;
using Integracion.Entities;
using Integracion.Extensions;
using Integracion.Models;
using Integracion.Utils;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Integracion.Controllers
{
    public class NotaVentaController : Controller
    {
        private readonly AppDbContext _context;
        private readonly Logger _logger;

        public NotaVentaController(AppDbContext context)
        {
            _context = context;
            _logger = new Logger(context);
        }
        public async Task<IActionResult> Index()
        {

            var fechaInicio = DateTime.Today.AddDays(-7);
            var ordenesDocumentos = await _context.orden_documento
                                            .Include(od => od.Documento)
                                            .Include(od => od.Orden)
                                            .Where(od =>
                                                    od.Documento.Fecdoc >= fechaInicio &&
                                                    od.Documento.Td == "NVV")
                                            .OrderByDescending(od => od.Documento.Fecdoc)
                                            .ToListAsync();

            var datos = new List<List<string>>();
            foreach (var ordenDocumento in ordenesDocumentos)
            {
                var boleta = _context.boleta.FirstOrDefault(b => b.NotaVentaId == ordenDocumento.DocumentoId);
                var documentoGenerado = "";
                if(boleta != null)
                {
                    var dsm = _context.dsm.FirstOrDefault(d => d.NotaVentaId == ordenDocumento.DocumentoId);
                    documentoGenerado = boleta.NumDocBoleta;
                    if(dsm != null)
                    {
                        documentoGenerado += " - " + dsm.NumDocDsm;
                    }
                }
                else
                {
                    var srf = _context.srf.FirstOrDefault(s => s.NotaVentaId == ordenDocumento.DocumentoId);
                    if(srf != null)
                    {
                        documentoGenerado = srf.NumDocSrf;
                    }
                }
                var total = ordenDocumento.Documento.Totdoc;
                var despacho = ordenDocumento.Orden.Despacho;
                var cliente = _context.cliente.FirstOrDefault(c => c.Rut == ordenDocumento.Documento.Idlegal);
                datos.Add(new List<string> {
                    ordenDocumento.Orden.ConExcepcion.ToString(),
                    ordenDocumento.Orden.FechaProcesamiento!=null?ordenDocumento.Orden.FechaProcesamiento.ToString():null,
                    ordenDocumento.Orden.Pickeada.ToString(),
                    ordenDocumento.Documento.Numdoc,
                    ordenDocumento.Documento.Numdoc,
                    String.Format("{0:dd-MM-yyyy}",ordenDocumento.Documento.Fecdoc),
                    cliente != null?cliente.Rut + "-" + cliente.Dg:"",
                    cliente != null?cliente.Ciudad:"",
                    "$" + String.Format("{0:N0}",total),
                    "$" + String.Format("{0:N0}",despacho),
                    documentoGenerado,
                    ordenDocumento.Documento.Iddocto.ToString(),
                });
            }
            ViewData["Datos"] = datos;

            var clientes = _context.cliente.Select(c => new SelectItem { Value = c.Rut, Text = "[" + c.Rut + "-" + c.Dg + "] " + c.Nombre}).ToList();
            var htmlClientes = "<select id='rut-facturador'><option value=''> -- Seleccione un cliente -- </option>";
            foreach(var cliente in clientes)
            {
                htmlClientes += "<option value='" + cliente.Value + "'>" + cliente.Text + "</option>";
            }
            htmlClientes += "</select>";
            ViewData["Clientes"] = htmlClientes.Replace("\"","");
            var filter = new FilterModel { FechaInicio = fechaInicio };
            return View(filter);
        }

        [HttpPost]
        public async Task<IActionResult> Index(FilterModel filterModel)
        {
            var datos = new List<List<string>>();
            var excepcion = filterModel.Excepcion;
            var procesadas = filterModel.Procesadas;
            if (ModelState.IsValid)
            {
                var fechaInicio = filterModel.FechaInicio;
                var fechaFin = filterModel.FechaFin;
                if (fechaFin != null)
                {
                    var tempFecha = (DateTime)fechaFin;
                    fechaFin = tempFecha.AddDays(1);
                }

                var ordenesDocumentos = new List<OrdenDocumento>();
                if (fechaInicio != null && fechaFin != null)
                {
                    ordenesDocumentos = _context.orden_documento
                                            .Include(od => od.Documento)
                                            .Include(od => od.Orden)
                                            .Where(od => od.Documento.Fecdoc >= fechaInicio && od.Documento.Fecdoc < fechaFin &&
                                                         od.Documento.Td == "NVV")
                                            .OrderByDescending(od => od.Documento.Fecdoc)
                                            .ToList();
                }
                if (fechaInicio == null && fechaFin != null)
                {
                    ordenesDocumentos = _context.orden_documento
                                            .Include(od => od.Documento)
                                            .Include(od => od.Orden)
                                            .Where(od => od.Documento.Fecdoc < fechaFin &&
                                                         od.Documento.Td == "NVV")
                                            .ToList();
                }
                if (fechaInicio != null && fechaFin == null)
                {
                    ordenesDocumentos = _context.orden_documento
                                            .Include(od => od.Documento)
                                            .Include(od => od.Orden)
                                            .Where(od => od.Documento.Fecdoc >= fechaInicio &&
                                                         od.Documento.Td == "NVV")
                                            .ToList();
                }
                if (fechaInicio == null && fechaFin == null)
                {
                    ordenesDocumentos = _context.orden_documento
                                            .Include(od => od.Documento)
                                            .Include(od => od.Orden)
                                            .Where(od => od.Documento.Td == "NVV")
                                            .ToList();
                }
                if (excepcion != null && excepcion != "TODAS")
                {
                    var conExcepcion = Convert.ToBoolean(excepcion);
                    ordenesDocumentos = ordenesDocumentos
                                            .Where(od => od.Orden.ConExcepcion == conExcepcion)
                                            .ToList();
                }
                if (procesadas != null && procesadas != "TODAS")
                {
                    var pendientes = !Convert.ToBoolean(procesadas);
                    if (pendientes)
                    {
                        ordenesDocumentos = ordenesDocumentos
                                            .Where(od => od.Orden.FechaProcesamiento == null)
                                            .ToList();
                    }
                    else
                    {
                        ordenesDocumentos = ordenesDocumentos
                                            .Where(od => od.Orden.FechaProcesamiento != null)
                                            .ToList();
                    }
                }

                foreach (var ordenDocumento in ordenesDocumentos)
                {
                    var boleta = _context.boleta.FirstOrDefault(b => b.NotaVentaId == ordenDocumento.DocumentoId);
                    var documentoGenerado = "";
                    if (boleta != null)
                    {
                        var dsm = _context.dsm.FirstOrDefault(d => d.NotaVentaId == ordenDocumento.DocumentoId);
                        documentoGenerado = boleta.NumDocBoleta;
                        if (dsm != null)
                        {
                            documentoGenerado += " - " + dsm.NumDocDsm;
                        }
                    }
                    else
                    {
                        var srf = _context.srf.FirstOrDefault(s => s.NotaVentaId == ordenDocumento.DocumentoId);
                        if (srf != null)
                        {
                            documentoGenerado = srf.NumDocSrf;
                        }
                    }
                    var total = ordenDocumento.Documento.Totdoc;
                    var despacho = ordenDocumento.Orden.Despacho;
                    var cliente = _context.cliente.FirstOrDefault(c => c.Rut == ordenDocumento.Documento.Idlegal);
                    datos.Add(new List<string> {
                        ordenDocumento.Orden.ConExcepcion.ToString(),
                        ordenDocumento.Orden.FechaProcesamiento!=null?ordenDocumento.Orden.FechaProcesamiento.ToString():null,
                        ordenDocumento.Orden.Pickeada.ToString(),
                        ordenDocumento.Documento.Numdoc,
                        ordenDocumento.Documento.Numdoc,
                        String.Format("{0:dd-MM-yyyy}",ordenDocumento.Documento.Fecdoc),
                        cliente != null?cliente.Rut + "-" + cliente.Dg:"",
                        cliente != null?cliente.Ciudad:"",
                        "$" + String.Format("{0:N0}",total),
                        "$" + String.Format("{0:N0}",despacho),
                        documentoGenerado,
                        ordenDocumento.Documento.Iddocto.ToString(),
                    });
                }
            }
            
            ViewData["Datos"] = datos;
            var clientes = _context.cliente.Select(c => new { Value = c.Rut, Text = "[" + c.Rut + "-" + c.Dg + "] " + c.Nombre }).ToList();
            var htmlClientes = "<select id='rut-facturador'><option value=''> -- Seleccione un cliente -- </option>";
            foreach (var cliente in clientes)
            {
                htmlClientes += "<option value='" + cliente.Value + "'>" + cliente.Text + "</option>";
            }
            htmlClientes += "</select>";
            ViewData["Clientes"] = htmlClientes.Replace("\"", "");
            return View(filterModel);
        }

        [HttpPost]
        public async Task<IActionResult> Procesar(string Documentos, string TipoProceso, string RutCliente, string NombreCliente)
        {
            var transaction = _context.Database.BeginTransaction();
            try
            {
                var NotasVenta = JsonConvert.DeserializeObject<List<int>>(Documentos);
                if (NotasVenta.Count == 0)
                {
                    throw new Exception("No hay notas de venta por procesar");
                }

                var parametro = _context.parametros.FirstOrDefault();
                var representante = "ANA";
                if (parametro != null)
                {
                    representante = parametro.Repre;
                }

                Documento primeraBoleta = null;
                Tabparidad primeraParidad = null;
                double? TotalVentasDSM = 0;
                double? TotalImpuesto = 0;
                var lineasDSM = new List<LineaDsm>();

                foreach (var idNotaVenta in NotasVenta)
                {
                    Documento documentoGenerado = null;
                    var notaVenta = _context.documento.Find(idNotaVenta);
                    if (notaVenta == null)
                    {
                        throw new Exception("No existe la nota de venta idDocto: " + idNotaVenta + " en la Base de Datos");
                    }

                    var fecha = new DateTime(notaVenta.Fecdoc.Value.Year, notaVenta.Fecdoc.Value.Month, notaVenta.Fecdoc.Value.Day);
                    var paridad = _context.paridad
                                    .Where(p =>
                                            p.Fecha == fecha &&
                                            p.Moneda == "DOL")
                                    .FirstOrDefault();
                    if (paridad == null)
                    {
                        throw new Exception("Error al cargar el tipo de cambio del " + String.Format("{0:dd-MM-yyyy}", notaVenta.Fecdoc) + " desde la Base de Datos.");
                    }

                    if (TipoProceso == Shared.TIPO_PROCESO_BOLETA)
                    {
                        var modulo = _context.modulo.Where(m =>
                                                    m.Modulo1 == Shared.LOCAL_M10)
                                            .FirstOrDefault();

                        if (modulo == null)
                        {
                            throw new Exception("Error al cargar el correlativo para la siguiente boleta desde la Base de Datos.");
                        }
                        notaVenta.Tdaduana = "BOL";

                        var siguiente = Convert.ToInt64(modulo.Boleta) + 1;
                        var correlativo = siguiente.ToString();
                        modulo.Boleta = correlativo;

                        var boleta = new Documento
                        {
                            Numdoc = correlativo,
                            Td = "BOL",
                            Fecdoc = new DateTime(notaVenta.Fecdoc.Value.Year, notaVenta.Fecdoc.Value.Month, notaVenta.Fecdoc.Value.Day),
                            Tdref = "NVV",
                            Docref = notaVenta.Numdoc,
                            Fecref = new DateTime(notaVenta.Fecdoc.Value.Year, notaVenta.Fecdoc.Value.Month, notaVenta.Fecdoc.Value.Day),
                            Idlegal = notaVenta.Idlegal,
                            Bodent = "",
                            Bodsal = Shared.BODEGA_B10,
                            Moneda = "PES",
                            Paridad = paridad.Valor,
                            Totdoc = notaVenta.Totdoc,
                            Codvend = Shared.VENDEDOR_WEB,
                            Codlpr = Shared.LPR,
                            Responsable = Shared.RESPONSABLE_WEB,
                            Pagado = "Si",
                            Fechgrab = DateTime.Now,
                            Usuario = Shared.USUARIO_WEB,
                            Estado = "T",
                        };

                        _context.Add(boleta);
                        _context.SaveChanges();

                        var nuevaBoleta = new Boleta
                        {
                            DocumentoId = boleta.Iddocto,
                            NotaVentaId = notaVenta.Iddocto,
                            NumDocBoleta = boleta.Numdoc,
                        };
                        _context.Add(nuevaBoleta);

                        _context.SaveChanges();

                        documentoGenerado = boleta;
                        if (primeraBoleta == null)
                        {
                            primeraBoleta = boleta;
                        }
                        if(primeraParidad == null)
                        {
                            primeraParidad = paridad;
                        }

                        var lineasNota = _context.documento_detalle
                                            .Where(dd => dd.Numdoc == notaVenta.Numdoc)
                                            .ToList();
                        double? lineaBoleta = 0;
                        foreach (var lineaNota in lineasNota)
                        {
                            var cantidadPendiente = lineaNota.Cant;
                            double? cantidadProcesada = 0;
                            while (cantidadPendiente > 0)
                            {
                                //saco el primer zeta que tenga saldofinal > 0
                                var zeta = _context.zetas
                                                    .Where(z => z.Codpro == lineaNota.Codpro && z.Salfinal > 0)
                                                    .OrderBy(z => z.Fecha)
                                                    .FirstOrDefault();
                                if (zeta == null)
                                {
                                    throw new Exception("Producto " + lineaNota.Codpro + " en nota de venta " + notaVenta.Numdoc + " no tiene código zeta asociado");
                                }
                                var cantidadZeta = zeta.Salfinal;

                                if (cantidadPendiente <= cantidadZeta)
                                {
                                    //si la cantidad que encontré en el zeta me alcanza,
                                    //proceso completa la cantidad que está pendiente
                                    cantidadProcesada = cantidadPendiente;
                                }
                                else
                                {
                                    //si la cantidad del zeta no me alcanza para procesar lo pendiente,
                                    //descuento la cantidad a procesar disponible en el zeta y hago otra línea
                                    cantidadProcesada = cantidadZeta;
                                }

                                var codzeta = zeta.Codzet;
                                double? cifuni = zeta.Cifuni;
                                var impuestoDolares = zeta.ImpuestoDolares(_context);
                                var impuestoPorUnidad = impuestoDolares * paridad.Valor;
                                var impuesto = impuestoPorUnidad * cantidadProcesada;
                                TotalImpuesto += impuesto;

                                lineaBoleta++;
                                //líneas de la boleta
                                var linea = new Documentod
                                {
                                    Iddocto = boleta.Iddocto,
                                    Td = "BOL",
                                    Numdoc = boleta.Numdoc,
                                    Sec = lineaBoleta,
                                    Fecdoc = boleta.Fecdoc,
                                    Codpro = lineaNota.Codpro,
                                    Cifuni = cifuni,
                                    Vtauni = lineaNota.Vtauni,
                                    Cant = lineaNota.Cant,
                                    Totlin = lineaNota.Vtauni * cantidadProcesada,
                                    Docref = notaVenta.Numdoc,
                                    Tdref = notaVenta.Td,
                                    Secref = lineaNota.Sec,
                                    Cantex = lineaNota.Cantex - cantidadProcesada,
                                    Cantce = 0,
                                    Paridad = lineaNota.Paridad,
                                    Responsable = Shared.RESPONSABLE_WEB,
                                    Codlocal = Shared.LOCAL_M10,
                                    Codbod = Shared.BODEGA_B10,
                                    Ctounit = lineaNota.Ctounit,
                                    Impuesto = impuesto,
                                    Codzet = codzeta,
                                };
                                _context.Add(linea);

                                TotalVentasDSM += linea.Vtauni * cantidadProcesada;

                                //descuento la cantidad del zeta
                                zeta.Salfinal -= cantidadProcesada;

                                //agrego el zeta para las líneas del DSM
                                lineasDSM.Add(new LineaDsm
                                {
                                    Cantidad = cantidadProcesada,
                                    CodZeta = codzeta,
                                    IdLinea = linea.Iddocto,
                                    NumeroDocumento = linea.Numdoc,
                                    CodPro = linea.Codpro,
                                    CifUni = linea.Cifuni,
                                    VtaUni = linea.Vtauni,
                                    Impuesto = linea.Impuesto,
                                });

                                cantidadPendiente -= cantidadProcesada;
                            }

                            //al crear una boleta descuento el stock físico de la bodega B10
                            var productoEnB10 = _context.bodega_producto.FirstOrDefault(bp =>
                                                                              bp.Codpro == lineaNota.Codpro &&
                                                                              bp.Codbod == Shared.BODEGA_B10);
                            if (productoEnB10 == null)
                            {
                                productoEnB10 = new Bodprod
                                {
                                    Codbod = Shared.BODEGA_B10,
                                    Codpro = lineaNota.Codpro,
                                    Comprometido = 0,
                                    Stfi = -lineaNota.Cant,
                                };
                                _context.bodega_producto.Add(productoEnB10);
                            }
                            else
                            {
                                productoEnB10.Stfi -= lineaNota.Cant;
                            }

                            _context.SaveChanges();
                        }
                    }

                    if (TipoProceso == Shared.TIPO_PROCESO_SRF)
                    {
                        if(RutCliente == "" || NombreCliente == "")
                        {
                            throw new Exception("Error: No se ha ingresado correctamente el Facturador.");
                        }
                        //folio para SRF según tabla de srf creados
                        var ultimoSrf = _context.srf.OrderByDescending(s => s.Id).FirstOrDefault();
                        var idSrf = 0;
                        if(ultimoSrf != null)
                        {
                            idSrf = ultimoSrf.Id;
                        }
                        notaVenta.Tdaduana = "SRF";

                        var folio = "8" + String.Format("{0:D9}", idSrf + 1);
                        var srf = new Documento
                        {
                            Numdoc = folio,
                            Td = "SRF",
                            Fecdoc = new DateTime(notaVenta.Fecdoc.Value.Year, notaVenta.Fecdoc.Value.Month, notaVenta.Fecdoc.Value.Day),
                            Tdref = "NVV",
                            Docref = notaVenta.Numdoc,
                            Fecref = new DateTime(notaVenta.Fecdoc.Value.Year, notaVenta.Fecdoc.Value.Month, notaVenta.Fecdoc.Value.Day),
                            Idlegal = RutCliente,
                            Bodent = "",
                            Bodsal = Shared.BODEGA_B01,
                            Moneda = "PES",
                            Paridad = 1,
                            Totdoc = notaVenta.Totdoc,
                            Codvend = Shared.VENDEDOR_WEB,
                            Codlpr = Shared.LPR,
                            Codadua = "PEN",
                            Coddest = "PEN",
                            Codpais = "PEN",
                            Condvta = "CONTADO",
                            Codvia = "PEN",
                            Codrepres = representante,
                            Responsable = Shared.RESPONSABLE_WEB,
                            Pagado = "Si",
                            Vend = Shared.VENDEDOR_WEB,
                            Rutfacto = RutCliente,
                            Nomfacto = NombreCliente,
                            Fechgrab = new DateTime(DateTime.Today.Year, DateTime.Today.Month, DateTime.Today.Day),
                            Foliolegal = "",
                            Usuario = Shared.USUARIO_WEB,
                            Saldo = notaVenta.Totdoc,
                            Centralizado = "SI",
                            Periodo = DateTime.Today.Year.ToString(),
                            Idbultos = "",
                            Qtybultos = 0,
                            Tpzeta = "",  
                            Codavanz = "PEN",
                            Codprocedencia = "EXT",
                            Codregion = "",
                            Codzfe = "IQQ",
                            Iva = 0,
                        };
                        _context.Add(srf);
                        documentoGenerado = srf;

                        notaVenta.Rutfacto = RutCliente;
                        notaVenta.Nomfacto = NombreCliente;

                        _context.SaveChanges();

                        var nuevoSrf = new Srf
                        {
                            DocumentoId = srf.Iddocto,
                            NotaVentaId = notaVenta.Iddocto,
                            NumDocSrf = srf.Numdoc,
                        };
                        _context.Add(nuevoSrf);
                        _context.SaveChanges();

                        //rescatar el PPE asociado a esta nota de venta
                        var PPE = _context.documento_picking.Include(dp => dp.Picking).FirstOrDefault(dp => dp.NotaVentaId == nuevoSrf.NotaVentaId);
                        var nroDocPPE = "";
                        if (PPE != null)
                        {
                            nroDocPPE = PPE.Picking.Numdoc;
                        }

                        var lineasNota = _context.documento_detalle
                                            .Where(dd => dd.Numdoc == notaVenta.Numdoc)
                                            .ToList();
                        double? lineaSrf = 0;
                        double? sumaImpuesto = 0;
                        foreach (var lineaNota in lineasNota)
                        {
                            var cantidadPendiente = lineaNota.Cant;
                            double? cantidadProcesada = 0;
                            while (cantidadPendiente > 0)
                            {
                                //saco el primer zeta que tenga saldofinal > 0
                                var zeta = _context.zetas
                                                    .Where(z => z.Codpro == lineaNota.Codpro && z.Salfinal > 0)
                                                    .OrderBy(z => z.Fecha)
                                                    .FirstOrDefault();
                                if (zeta == null)
                                {
                                    throw new Exception("Producto " + lineaNota.Codpro + " en nota de venta " + notaVenta.Numdoc + " no tiene código zeta asociado");
                                }
                                var cantidadZeta = zeta.Salfinal;

                                if (cantidadPendiente <= cantidadZeta)
                                {
                                    //si la cantidad que encontré en el zeta me alcanza,
                                    //proceso completa la cantidad que está pendiente
                                    cantidadProcesada = cantidadPendiente;
                                }
                                else
                                {
                                    //si la cantidad del zeta no me alcanza para procesar lo pendiente,
                                    //descuento la cantidad a procesar disponible en el zeta y hago otra línea
                                    cantidadProcesada = cantidadZeta;
                                }

                                var codzeta = zeta.Codzet;
                                double? cifuni = zeta.Cifuni;
                                var impuestoDolares = zeta.ImpuestoDolares(_context);
                                var impuestoPorUnidad = impuestoDolares * paridad.Valor;
                                var impuesto = impuestoPorUnidad * cantidadProcesada;
                                TotalImpuesto += impuesto;

                                lineaSrf++;
                                var linea = new Documentod
                                {
                                    Iddocto = srf.Iddocto,
                                    Td = "SRF",
                                    Numdoc = srf.Numdoc,
                                    Sec = lineaSrf,
                                    Fecdoc = srf.Fecdoc,
                                    Codpro = lineaNota.Codpro,
                                    Codzet = codzeta,
                                    Cifuni = cifuni,
                                    Vtauni = lineaNota.Vtauni,
                                    Cant = cantidadProcesada,
                                    Totlin = lineaNota.Vtauni * cantidadProcesada,
                                    Despacha = "",
                                    Entregada = "",
                                    Docref = nroDocPPE,
                                    Tdref = "PPE",
                                    Secref = lineaNota.Sec,
                                    Cantex = 0,
                                    Cantce = 0,
                                    Responsable = Shared.RESPONSABLE_WEB,
                                    Codlocal = Shared.LOCAL_ECOMMERCE,
                                    Codbod = Shared.BODEGA_B01,
                                    Ctounit = lineaNota.Ctounit,
                                    Impuesto = impuesto,
                                };
                                sumaImpuesto += impuesto;
                                _context.Add(linea);

                                //resto la cantidad procesada en cantex
                                lineaNota.Cantex -= cantidadProcesada;

                                //descuento la cantidad del zeta
                                zeta.Salfinal -= cantidadProcesada;
                                
                                _context.SaveChanges();

                                cantidadPendiente -= cantidadProcesada;
                            }
                        }
                        //actualizo el impuesto del SRF recién creado según la suma
                        srf.Mtoimpto = sumaImpuesto;
                        _context.SaveChanges();
                    }

                    //creo los detalles de pago
                    var pago = _context.pago_documento
                                            .Include(pd => pd.Pago)
                                            .FirstOrDefault(pd => pd.DocumentoId == notaVenta.Iddocto)
                                            .Pago;

                    if (pago != null)
                    {
                        var pagoD = new PagoD
                        {
                            Idpago = pago.Idpago,
                            Iddocto = documentoGenerado.Iddocto,
                            Docref = documentoGenerado.Numdoc,
                            Fecpag = documentoGenerado.Fecdoc,
                            Valdolar = pago.Valdolar,
                            Monto = documentoGenerado.Totdoc,
                            Diftpc = 0,
                            Fechareal = new DateTime(DateTime.Today.Year, DateTime.Today.Month, DateTime.Today.Day),
                        };
                        _context.Add(pagoD);
                        //En caso de haber procesado una boleta, cambiar campo Bol del Pago_E
                        if(TipoProceso == Shared.TIPO_PROCESO_BOLETA)
                        {
                            pago.Bol = "BOL-" + documentoGenerado.Numdoc + "-1";
                            pago.Mark = null;
                        }
                        //En caso de haber procesado un SRF, cambiar campo Mark
                        if (TipoProceso == Shared.TIPO_PROCESO_SRF)
                        {
                            pago.Mark = "1";
                            pago.Bol = "MAY";
                        }

                        //Al momento de crear el pagoD debo ir descontando del SALDO del documentogenerado
                        documentoGenerado.Saldo -= documentoGenerado.Totdoc;
                    }
                    else
                    {
                        throw new Exception("El pago asociado a la nota de venta " + notaVenta.Numdoc + " es incorrecto.");
                    }

                    var orden = _context.orden_documento
                                                .Include(od => od.Orden)
                                                .FirstOrDefault(od => od.DocumentoId == notaVenta.Iddocto)
                                                .Orden;
                    if(orden != null)
                    {
                        orden.FechaProcesamiento = DateTime.Now;
                    }

                    //Asignar campo Tdaduana BOL o SRF en documento de picking
                    //Campo rutfacto y nomfacto en documento picking si es boleta va el del cliente y si es SRF es el rut y nombre facturador
                    var documentoPicking = _context.documento_picking
                                                        .Include(dp => dp.Picking)
                                                        .FirstOrDefault(dp => dp.NotaVentaId == notaVenta.Iddocto);
                    if(documentoPicking != null)
                    {
                        if (TipoProceso == Shared.TIPO_PROCESO_BOLETA)
                        {
                            documentoPicking.Picking.Rutfacto = notaVenta.Rutfacto;
                            documentoPicking.Picking.Nomfacto = notaVenta.Nomfacto;
                            documentoPicking.Picking.Tdaduana = "BOL";
                        }
                        
                        else if (TipoProceso == Shared.TIPO_PROCESO_SRF)
                        {
                            documentoPicking.Picking.Rutfacto = RutCliente;
                            documentoPicking.Picking.Nomfacto = NombreCliente;
                            documentoPicking.Picking.Tdaduana = "SRF";
                        }   
                    }

                    _context.SaveChanges();
                }

                //Si se crearon boletas, ahora debo crear el DSM para el conjunto de boletas generadas
                if(primeraBoleta != null && TipoProceso == Shared.TIPO_PROCESO_BOLETA)
                {
                    //folio para DSM según tabla de dsm creados
                    var ultimoDsm = _context.dsm.OrderByDescending(d => d.Id).FirstOrDefault();
                    var idDsm = 0;
                    if (ultimoDsm != null)
                    {
                        idDsm = ultimoDsm.Id;
                    }
                    var folioDSM = "7" + String.Format("{0:D9}", idDsm + 1);
                    
                    var dsm = new Documento
                    {
                        Numdoc = folioDSM,
                        Td = "DSM",
                        Fecdoc = primeraBoleta.Fecdoc,
                        Tdref = "BOL",
                        Docref = primeraBoleta.Numdoc,
                        Fecref = primeraBoleta.Fecdoc,
                        Idlegal = Shared.RUT_EMPRESA,
                        Bodent = Shared.BODEGA_B10,
                        Bodsal = Shared.BODEGA_B01,
                        Moneda = "PES",
                        Paridad = 1,
                        Totdoc = TotalVentasDSM,
                        Codvend = Shared.VENDEDOR_WEB,
                        Codlpr = Shared.LPR,
                        Codadua = "PEN",
                        Coddest = "PEN",
                        Codpais = "PEN",
                        Condvta = "CONTADO",
                        Codvia = "TRA",
                        Codrepres = representante,
                        Pagado = "NO",
                        Rutfacto = Shared.RUT_EMPRESA,
                        Nomfacto = Shared.NOMBRE_EMPRESA,
                        Mtoimpto = TotalImpuesto,
                        Fechgrab = DateTime.Today,
                        Usuario = Shared.USUARIO_WEB,
                        Saldo = TotalVentasDSM,
                        Iva = 0,
                        Centralizado = "NO",
                        Estado = "T",
                        Periodo = DateTime.Today.Year.ToString(),
                        Qtybultos = 0,
                        Idbultos = "",
                        Tpzeta = "",
                        Codavanz = "",
                        Codprocedencia = "",
                        Codregion = "",
                        Codzfe = "",
                    };

                    _context.Add(dsm);
                    _context.SaveChanges();

                    var notaBoleta = _context.boleta.FirstOrDefault(nb => nb.DocumentoId == primeraBoleta.Iddocto);
                    var nuevoDsm = new Dsm
                    {
                        DocumentoId = dsm.Iddocto,
                        NotaVentaId = notaBoleta.NotaVentaId,
                        NumDocDsm = dsm.Numdoc,
                    };
                    _context.Add(nuevoDsm);
                    _context.SaveChanges();

                    //acumular las líneas de DSM, si se repite la línea se pone la primera
                    lineasDSM = Util.Group(lineasDSM);

                    //rescatar el PPE asociado a esta nota de venta
                    var PPE = _context.documento_picking.Include(dp => dp.Picking).FirstOrDefault(dp => dp.NotaVentaId == nuevoDsm.NotaVentaId);
                    var nroDocPPE = "";
                    if(PPE != null)
                    {
                        nroDocPPE = PPE.Picking.Numdoc;
                    }

                    //ahora agrego las líneas del DSM
                    var lineaDDsm = 0;
                    foreach(var lineaDSM in lineasDSM)
                    {
                        double? costoUnitario = 0;
                        lineaDDsm++;
                        var stoart = _context.stock_articulo.FirstOrDefault(p => p.Codpro == lineaDSM.CodPro);
                        if (stoart != null)
                        {
                            costoUnitario = stoart.CupMlocal;
                        }

                        //En el DSM agregar el valor de referencia del PPE asociado
                        var pickingLinea = _context.picking_linea
                                                .Include(pl => pl.PickingDetalle)
                                                .OrderByDescending(pl => pl.Id)
                                                .FirstOrDefault(pl => pl.LineaNotaVentaId == lineaDSM.IdLinea);

                        var bultosRef = "";
                        if (pickingLinea != null)
                        {
                            bultosRef = pickingLinea.PickingDetalle.Bultosref;
                        }

                        var dsmD = new Documentod
                        {
                            Iddocto = Convert.ToInt32(dsm.Iddocto),
                            Numdoc = dsm.Numdoc,
                            Td = "DSM",
                            Sec = lineaDDsm,
                            Fecdoc = dsm.Fecdoc,
                            Codpro = lineaDSM.CodPro,
                            Codzet = lineaDSM.CodZeta,
                            Cifuni = lineaDSM.CifUni,
                            Vtauni = lineaDSM.VtaUni,
                            Cant = lineaDSM.Cantidad,
                            Totlin = lineaDSM.VtaUni * lineaDSM.Cantidad,
                            Despacha = "",
                            Entregada = "",
                            Docref = nroDocPPE,
                            Tdref = "PPE",
                            Secref = 1,
                            Cantex = 0,
                            Cantce = 0,
                            Codbod = Shared.BODEGA_B01,
                            Ctounit = costoUnitario,
                            Impuesto = lineaDSM.Impuesto,
                            Bultosref = bultosRef,
                        };
                        _context.Add(dsmD);

                        //al crear el DSM debo aumentar el stock físico de la bodega B10
                        var productoEnB10 = _context.bodega_producto.FirstOrDefault(bp =>
                                                                              bp.Codpro == lineaDSM.CodPro &&
                                                                              bp.Codbod == Shared.BODEGA_B10);
                        if (productoEnB10 == null)
                        {
                            productoEnB10 = new Bodprod
                            {
                                Codbod = Shared.BODEGA_B10,
                                Codpro = lineaDSM.CodPro,
                                Comprometido = 0,
                                Stfi = lineaDSM.Cantidad,
                            };
                            _context.bodega_producto.Add(productoEnB10);
                        }
                        else
                        {
                            productoEnB10.Stfi += lineaDSM.Cantidad;
                        }

                    }
                    _context.SaveChanges();
                }

                transaction.Commit();
                return Json(new { status = "SUCCESS", mensaje = NotasVenta.Count + " notas de venta procesadas correctamente." });
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                _logger.Error("No se pudieron procesar los documentos. Excepción: " + ex.Message);
                return Json(new { status = "ERROR", mensaje = ex.Message });
            }
        }

        public async Task<IActionResult> Details(string Id)
        {
            try
            {
                var OrdenDocumento = await _context.orden_documento
                                            .Include(od => od.Orden)
                                            .Include(od => od.Documento)
                                            .FirstOrDefaultAsync(od => od.Documento.Numdoc == Id);

                var detalles = await _context.documento_detalle
                                            .Where(dd => dd.Numdoc == Id)
                                            .ToListAsync();

                var boleta = _context.boleta.Include(b => b.Documento).FirstOrDefault(b => b.NotaVentaId == OrdenDocumento.DocumentoId);
                var dsm = _context.dsm.Include(d => d.Documento).FirstOrDefault(d => d.NotaVentaId == OrdenDocumento.DocumentoId);
                var srf = _context.srf.Include(s => s.Documento).FirstOrDefault(s => s.NotaVentaId == OrdenDocumento.DocumentoId);
                var picking = _context.documento_picking.Include(dp => dp.Picking).Where(dp => dp.NotaVentaId == OrdenDocumento.DocumentoId).FirstOrDefault();

                var lineasNota = new List<LineaNotaVenta>();
                foreach (var linea in detalles)
                {
                    var producto = _context.stock_articulo.FirstOrDefault(p => p.Codpro == linea.Codpro);
                    lineasNota.Add(new LineaNotaVenta
                    {
                        Cantidad = Convert.ToInt32(linea.Cant),
                        CodigoProducto = linea.Codpro,
                        DescripcionProducto = producto != null ? producto.Descri : "",
                        CostoUnitario = Convert.ToInt32(linea.Ctounit),
                        PrecioVenta = Convert.ToInt32(linea.Vtauni),
                        Secuencia = Convert.ToInt32(linea.Sec),
                        TotalLinea = Convert.ToInt32(linea.Totlin),
                        DocDId = linea.Iddoctod,
                        Bultos = linea.Bultosref,
                    });
                }

                var excepcionesNota = await _context.excepcion_orden
                                                .Where(eo => eo.ProcesoId == OrdenDocumento.Orden.Id)
                                                .ToListAsync();

                var cliente = _context.cliente.FirstOrDefault(c => c.Rut == OrdenDocumento.Documento.Idlegal);
                var notaVenta = new NotaVenta
                {
                    IdDocumento = OrdenDocumento.Documento.Iddocto,
                    NumDocumento = OrdenDocumento.Documento.Numdoc,
                    CostoDespacho = Convert.ToInt32(OrdenDocumento.Orden.Despacho),
                    FechaCreacion = OrdenDocumento.Orden.FechaImportacion,
                    FechaDocumento = OrdenDocumento.Documento.Fecdoc,
                    FechaEntrega = OrdenDocumento.Documento.FecEnt,
                    FechaOC = OrdenDocumento.Documento.Fecref,
                    MontoVenta = Convert.ToInt32(OrdenDocumento.Documento.Totdoc),
                    NombreCliente = OrdenDocumento.Documento.Nomfacto,
                    OC = OrdenDocumento.Documento.Docref,
                    RutCliente = cliente != null ? cliente.Rut + "-" + cliente.Dg : "",
                    Lineas = lineasNota,
                    Excepciones = excepcionesNota,
                    Boleta = boleta,
                    Dsm = dsm,
                    Srf = srf,
                    OrdenCompra = OrdenDocumento.Orden,
                    Picking = picking,
                };
                return View(notaVenta);
            }
            catch (Exception)
            {

                return RedirectToAction(nameof(Index));
            }
            
            
        }

        [HttpPost]
        public async Task<IActionResult> Pickear(string Bultos, int IdDocumento)
        {
            var transaction = _context.Database.BeginTransaction();
            try
            {
                var BultosLineas = JsonConvert.DeserializeObject<List<BultoLinea>>(Bultos);
                if (BultosLineas == null || BultosLineas.Count == 0)
                {
                    throw new Exception("No hay líneas a las cuales realizarles picking");
                }
                var fecha = new DateTime(DateTime.Today.Year, DateTime.Today.Month, DateTime.Today.Day);
                var paridad = _context.paridad
                                        .Where(p =>
                                                p.Fecha == fecha &&
                                                p.Moneda == "DOL")
                                        .FirstOrDefault();
                if (paridad == null)
                {
                    throw new Exception("No se encuentra el tipo de cambio para hoy en la BD " + String.Format("{0:dd-MM-yyyy}",DateTime.Today));
                }
                var notaVenta = _context.documento.Find(IdDocumento);
                var ultimoPicking = _context.documento_picking.OrderByDescending(p => p.Id).FirstOrDefault();
                var idPicking = 0;
                if (ultimoPicking != null)
                {
                    idPicking = ultimoPicking.Id;
                }
                var folioPicking = "6" + String.Format("{0:D9}", idPicking + 1);

                //realizar el picking en la BD
                var picking = new Documento
                {
                    Numdoc = folioPicking,
                    Td = "PPE",
                    Fecdoc = DateTime.Today,
                    Idlegal = notaVenta.Idlegal,
                    Bodsal = Shared.BODEGA_B01,
                    Moneda = "PES",
                    Paridad = 1,
                    Totdoc = notaVenta.Totdoc,
                    Comdoc = "",
                    Codvend = Shared.VENDEDOR_WEB,
                    Codlpr = Shared.LPR,
                    Condvta = "CONTADO",
                    Codvia = "PEN",
                    Tdaduana = "PEN",
                    Pagado = "NO",
                    Rutfacto = "",
                    Nomfacto = "",
                    Fechgrab = DateTime.Today,
                    Usuario = Shared.USUARIO_WEB,
                    Iva = 0,
                    Btp = "",
                    Estado = "T",
                    Tcpactado = paridad.Valor,
                };
                _context.Add(picking);
                _context.SaveChanges();

                var documentoPicking = new DocumentoPicking
                {
                    NotaVentaId = notaVenta.Iddocto,
                    PickingId = picking.Iddocto,
                    Fecha = DateTime.Today,
                };
                _context.Add(documentoPicking);

                var secuencia = 1;
                foreach(var bultoLinea in BultosLineas)
                {
                    var linea = _context.documento_detalle.Find(bultoLinea.LineaId);
                    var pickingDetalle = new Documentod
                    {
                        Iddocto = picking.Iddocto, 
                        Numdoc = picking.Numdoc,
                        Td = "PPE",
                        Sec = secuencia,
                        Fecdoc = picking.Fecdoc,
                        Codpro = linea.Codpro,
                        Vtauni = linea.Vtauni, 
                        Cant = linea.Cant,
                        Totlin = linea.Vtauni * linea.Cant,
                        Docref = linea.Numdoc, 
                        Tdref = "NVV",
                        Secref = linea.Sec,
                        Cantex = linea.Cant,
                        Cantce = 0,
                        Paridad = paridad.Valor,
                        Codbod = Shared.BODEGA_B01,
                        Ctounit = linea.Ctounit,
                        Bultosref = bultoLinea.Bultos,
                        Impuesto = 0,
                    };
                    _context.Add(pickingDetalle);
                    secuencia++;

                    //Agrego la información de bultos en la línea de nota de venta
                    linea.Bultosref = bultoLinea.Bultos;

                    _context.SaveChanges();

                    var pickingLinea = new PickingLinea
                    {
                        PickingDetalleId = pickingDetalle.Iddoctod,
                        LineaNotaVentaId = linea.Iddoctod,
                    };
                    _context.Add(pickingLinea);

                    //al crear el PPE descuento el stock físico de B01 y el stock comprometido de B01
                    var stockProducto = _context.bodega_producto.FirstOrDefault(bp =>
                                                        bp.Codbod == Shared.BODEGA_B01 &&
                                                        bp.Codpro == linea.Codpro);
                    if (stockProducto != null)
                    {
                        stockProducto.Stfi -= linea.Cant;
                        stockProducto.Comprometido -= linea.Cant;
                    }
                    else
                    {
                        throw new Exception("ADVERTENCIA: El producto " + linea.Codpro + " no se encuentra en la bodega " + Shared.BODEGA_B01 + ". No se pudo rebajar el stock.");
                    }

                }
               _context.SaveChanges();

                //marco la orden como pickeada
                var ordenDocumento = _context.orden_documento.Include(od => od.Orden).FirstOrDefault(od => od.Documento.Iddocto == IdDocumento);
                if(ordenDocumento != null)
                {
                    if(ordenDocumento.Orden != null)
                    {
                        ordenDocumento.Orden.Pickeada = true;
                        _context.SaveChanges();
                    }
                }
                transaction.Commit();
                return Json(new { status = "SUCCESS", mensaje = "Proceso de picking finalizado con éxito." });
            }
            catch(Exception ex)
            {
                transaction.Rollback();
                return Json(new { status = "ERROR", mensaje = ex.Message });
            }
           
        }

    }
}
