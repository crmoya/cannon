﻿using Integracion.Data;
using Integracion.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;

namespace Integracion.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbContext _context;

        public HomeController(AppDbContext context)
        {
            _context = context;
        }
        public async Task<IActionResult> Login()
        {
            if(HttpContext.Session.GetString("usuario") != null && HttpContext.Session.GetString("usuario") != "")
            {
                return RedirectToAction("Index", "NotaVenta");
            }
            return View();
        }

        public async Task<IActionResult> Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login", "Home");
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginModel loginModel)
        {
            if(ModelState.IsValid)
            {
                var usuario = _context.usuarios.FirstOrDefault(u => u.Nombre == loginModel.Usuario && u.Pwd == loginModel.Clave);
                if(usuario != null)
                {
                    HttpContext.Session.SetString("usuario", usuario.NomUsuario);
                    return RedirectToAction("Index", "NotaVenta");
                }
                else
                {
                    ModelState.AddModelError("Usuario", "Usuario / Clave no encontrados");
                }
            }
            return View(loginModel);
        }

        public async Task<IActionResult> Error()
        {
            return View();
        }

    }
}
