﻿using Integracion.Data;
using Integracion.Entities;
using Integracion.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Integracion.Controllers
{
    public class EventLogController : Controller
    {
        private readonly AppDbContext _context;

        public EventLogController(AppDbContext context)
        {
            _context = context;
        }

        // GET: EventLog
        public async Task<IActionResult> Index()
        {
            var fechaInicio = DateTime.Today;
            var eventos = _context.log_evento
                            .Where(e => e.Fecha >= fechaInicio && e.Tipo == Utils.LogType.ERROR)
                            .OrderByDescending(e => e.Id).ToList();
            var datos = new List<List<string>>();
            foreach (var evento in eventos)
            {
                datos.Add(new List<string> {
                    evento.Id.ToString(),
                    String.Format("{0:dd-MM-yyyy HH:mm:ss}",evento.Fecha),
                    evento.Mensaje,
                    evento.Tipo == Utils.LogType.INFO?"INFO":"ERROR",
                });
            }
            ViewData["Datos"] = datos;
            var filterModel = new FilterModel { FechaInicio = fechaInicio, TipoLog = "ERRORES" };
            return View(filterModel);
        }

        [HttpPost]
        public async Task<IActionResult> Index(FilterModel filterModel)
        {
            var fechaInicio = filterModel.FechaInicio;
            var fechaFin = filterModel.FechaFin;
            var tipoLog = filterModel.TipoLog;

            if (fechaFin != null)
            {
                var tempFecha = (DateTime)fechaFin;
                fechaFin = tempFecha.AddDays(1);
            }
            var eventos = new List<EventLog>();
            if (fechaInicio != null && fechaFin != null)
            {
                eventos = _context.log_evento
                                    .Where(e => e.Fecha >= fechaInicio && e.Fecha < fechaFin)
                                    .OrderByDescending(e => e.Id)
                                    .ToList();
            }
            if (fechaInicio == null && fechaFin != null)
            {
                eventos = _context.log_evento
                                    .Where(e => e.Fecha < fechaFin)
                                    .OrderByDescending(e => e.Id)
                                    .ToList();
            }
            if (fechaInicio != null && fechaFin == null)
            {
                eventos = _context.log_evento
                                    .Where(e => e.Fecha >= fechaInicio)
                                    .OrderByDescending(e => e.Id)
                                    .ToList();
            }
            if (fechaInicio == null && fechaFin == null)
            {
                eventos = _context.log_evento.OrderByDescending(e => e.Id).ToList();
            }
            if(tipoLog != null)
            {
                if(tipoLog == "ERRORES")
                {
                    eventos = eventos.Where(e => e.Tipo == Utils.LogType.ERROR).ToList();
                }
                if (tipoLog == "INFORMATIVOS")
                {
                    eventos = eventos.Where(e => e.Tipo == Utils.LogType.INFO).ToList();
                }
            }

            var datos = new List<List<string>>();
            foreach (var evento in eventos)
            {
                datos.Add(new List<string> {
                    evento.Id.ToString(),
                    String.Format("{0:dd-MM-yyyy HH:mm:ss}",evento.Fecha),
                    evento.Mensaje,
                    evento.Tipo == Utils.LogType.INFO?"INFO":"ERROR",
                });
            }
            ViewData["Datos"] = datos;
            return View();
        }

        public async Task<IActionResult> Details(int Id)
        {
            var EventLog = _context.log_evento.Find(Id);
            if(EventLog == null)
            {
                return NotFound();
            }
            return View(EventLog);

        }
    }
}
