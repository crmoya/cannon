﻿using Integracion.Data;
using Integracion.Entities;
using Integracion.Utils;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Integracion.Tasks
{
    public class RecurringTask: IHostedService
    {

        private Timer _timer;
        private int FrecuenciaEnMinutos = 60;
        private readonly AppDbContext _context;
        private readonly Logger _logger;

        public RecurringTask(AppDbContext db)
        {            
            _context = db;
            _logger = new Logger(db);
        }

        public Task StartAsync(CancellationToken cancellationToken)
        {
            _timer = new Timer(
                SecuencialTasks,
                null,
                TimeSpan.Zero,
                TimeSpan.FromMinutes(FrecuenciaEnMinutos)
            );

            return Task.CompletedTask;
        }

        private void SecuencialTasks(object state)
        {
            GetOrdersFromMagentoAsync();
            checkRepairedExceptions();
            CheckModifiedStocks();
        }

        public Task StopAsync(CancellationToken cancellationToken)
        {
            _timer?.Change(Timeout.Infinite, 0);
            return Task.CompletedTask;
        }
    
        private void GetOrdersFromMagentoAsync()
        {
            var procesadas = 0;
            try
            {
                var api = new API(_context);

                //TO-DO definir desde cuándo cargar órdenes
                var fechaInicio = DateTime.Today.AddDays(-7);
                var confirmedOrders = api.GetOrdersSince(Shared.ESTADO_ORDEN_CONFIRMADA, fechaInicio).Result;
                
                if(confirmedOrders != null)
                {
                    foreach (var order in confirmedOrders)
                    {
                        //reviso que no haya procesado la orden anteriormente
                        if (!_context.orden_procesada.Any(o => o.OrdenId == order.Increment_Id))
                        {
                            var transaction = _context.Database.BeginTransaction();
                            try
                            {
                                var customer = order.Customer;
                                if (customer == null)
                                {
                                    _logger.Error("ORDEN " + order.Increment_Id + " no se puede procesar, debido a que no cuenta con cliente asociado.");
                                    transaction.Rollback();
                                    continue;
                                }

                                //la proceso
                                var procesada = new OrdenProcesada
                                {
                                    OrdenId = order.Increment_Id,
                                    EntityId = order.Entity_Id,
                                    FechaImportacion = DateTime.Now,
                                };
                                _context.Add(procesada);
                                _context.SaveChanges();

                                DateTime? fechaOrden = null;
                                try
                                {
                                    fechaOrden = order.Created_At;
                                    if (fechaOrden == null)
                                    {
                                        throw new Exception("Fecha inválida");
                                    }
                                }
                                catch (Exception)
                                {
                                    var excepcion = new ExcepcionOrdenProcesada
                                    {
                                        Atributo = "Fecha",
                                        Excepcion = "Fecha de la orden no tiene el formato correcto",
                                        ProcesoId = procesada.Id
                                    };
                                    _context.Add(excepcion);
                                    procesada.ConExcepcion = true;
                                }
                                string rut = null;
                                try
                                {
                                    rut = customer.Rut;
                                    if (rut == null)
                                    {
                                        throw new Exception("RUT de cliente no existe");
                                    }
                                }
                                catch (Exception)
                                {
                                    var excepcion = new ExcepcionOrdenProcesada
                                    {
                                        Atributo = "Rut",
                                        Excepcion = "RUT del cliente no se encuentra",
                                        ProcesoId = procesada.Id
                                    };
                                    _context.Add(excepcion);
                                    procesada.ConExcepcion = true;
                                }

                                string dv = null;
                                try
                                {
                                    dv = customer.DV;
                                    if (dv == null)
                                    {
                                        throw new Exception("RUT no tiene guión");
                                    }
                                }
                                catch (Exception)
                                {
                                    var excepcion = new ExcepcionOrdenProcesada
                                    {
                                        Atributo = "Rut",
                                        Excepcion = "RUT no tiene guión",
                                        ProcesoId = procesada.Id
                                    };
                                    _context.Add(excepcion);
                                    procesada.ConExcepcion = true;
                                }

                                string nombre = null;
                                try
                                {
                                    if (customer.Firstname == null && customer.Lastname == null)
                                    {
                                        throw new Exception("Nombre del cliente no se encuentra");
                                    }
                                    else
                                    {
                                        nombre = customer.Firstname + " " + customer.Lastname;
                                    }
                                }
                                catch (Exception)
                                {
                                    var excepcion = new ExcepcionOrdenProcesada
                                    {
                                        Atributo = "Nombre",
                                        Excepcion = "Nombre del cliente no se encuentra",
                                        ProcesoId = procesada.Id
                                    };
                                    _context.Add(excepcion);
                                    procesada.ConExcepcion = true;
                                }
                                string direccion = null;
                                try
                                {
                                    direccion = customer.Direccion;
                                    if (direccion == null)
                                    {
                                        throw new Exception("Dirección del cliente errónea");
                                    }
                                }
                                catch (Exception)
                                {
                                    var excepcion = new ExcepcionOrdenProcesada
                                    {
                                        Atributo = "Direccion",
                                        Excepcion = "Dirección del cliente no se encuentra",
                                        ProcesoId = procesada.Id
                                    };
                                    _context.Add(excepcion);
                                    procesada.ConExcepcion = true;
                                }
                                string email = null;
                                try
                                {
                                    email = customer.Email;
                                    if (email == null)
                                    {
                                        throw new Exception("E-mail del cliente no se encuentra");
                                    }
                                }
                                catch (Exception)
                                {
                                    var excepcion = new ExcepcionOrdenProcesada
                                    {
                                        Atributo = "Email",
                                        Excepcion = "E-mail del cliente no se encuentra",
                                        ProcesoId = procesada.Id
                                    };
                                    _context.Add(excepcion);
                                    procesada.ConExcepcion = true;
                                }
                                string telefono = null;
                                try
                                {
                                    telefono = customer.Fono;
                                    if (telefono == null)
                                    {
                                        throw new Exception("Teléfono del cliente no se encuentra");
                                    }
                                }
                                catch (Exception)
                                {
                                    var excepcion = new ExcepcionOrdenProcesada
                                    {
                                        Atributo = "Telefono",
                                        Excepcion = "Teléfono del cliente no se encuentra",
                                        ProcesoId = procesada.Id
                                    };
                                    _context.Add(excepcion);
                                    procesada.ConExcepcion = true;
                                }

                                procesada.Despacho = order.Shipping_Amount;

                                //reviso si está la ciudad en la BD IQQ, sino creo una excepción
                                var ciudad = customer.Ciudad;
                                if (ciudad != null && ciudad != "")
                                {
                                    ciudad = Util.RemoveAccents(ciudad);
                                    var ciudadBD = _context.tipo_documento
                                                        .FirstOrDefault(td => td.Clase == "CIU" && td.Namedocumento == ciudad.ToUpper());
                                    if (ciudadBD == null)
                                    {
                                        var excepcion = new ExcepcionOrdenProcesada
                                        {
                                            Atributo = "Ciudad",
                                            Excepcion = "Ciudad " + ciudad + " no está ingresada en su sistema",
                                            ProcesoId = procesada.Id
                                        };
                                        _context.Add(excepcion);
                                        procesada.ConExcepcion = true;
                                    }
                                }

                                //creo al cliente, o actualizo sus datos según Magento
                                var clienteBD = _context.cliente.Find(rut);
                                var nuevo = false;
                                if (clienteBD == null)
                                {
                                    nuevo = true;
                                    clienteBD = new Faccli();
                                    clienteBD.Codcli = rut;
                                }
                                clienteBD.Rut = rut;
                                clienteBD.Dg = dv;
                                clienteBD.Tipo = "C";
                                clienteBD.Vigencia = "1";
                                clienteBD.Nombre = nombre;
                                clienteBD.Pais = "CHILE";
                                clienteBD.Direc = direccion;
                                clienteBD.Fono = telefono;
                                clienteBD.Fax = telefono;
                                clienteBD.Email = email;
                                clienteBD.Vend = Shared.VENDEDOR_WEB;
                                clienteBD.CondPag = "C00";
                                clienteBD.CredMax = 0;
                                clienteBD.Lpr = Shared.LPR;
                                clienteBD.Modopago = "PES";
                                clienteBD.Clasif = 0;
                                clienteBD.Ciudad = ciudad;
                                clienteBD.Comuna = ciudad;
                                if (nuevo)
                                {
                                    _context.cliente.Add(clienteBD);
                                }

                                _context.SaveChanges();

                                var montoNotaVenta = order.Subtotal_Incl_Tax;
                                if (montoNotaVenta == 0)
                                {
                                    throw new Exception("El monto total a pagar de la orden es 0.");
                                }

                                //creo una nota de venta
                                var notaVenta = new Documento
                                {
                                    Td = "NVV",
                                    Numdoc = "9" + String.Format("{0:D9}", procesada.Id),
                                    Bodent = Shared.BODEGA_B01,
                                    Bodsal = Shared.BODEGA_B01,
                                    Paridad = 1,
                                    Tcpactado = 1,
                                    Fecdoc = order.Created_At,
                                    Moneda = "PES",
                                    Docref = order.Increment_Id,
                                    Fecref = order.Created_At,
                                    Idlegal = rut,
                                    Totdoc = montoNotaVenta,
                                    Codvend = Shared.VENDEDOR_WEB,
                                    Responsable = Shared.RESPONSABLE_WEB,
                                    Condvta = "CONTADO",
                                    Pagado = "Si",
                                    Vend = Shared.VENDEDOR_WEB,
                                    FecEnt = order.Created_At.AddDays(5),
                                    Rutfacto = rut,
                                    Nomfacto = nombre,
                                    Fechgrab = DateTime.Now,
                                    Usuario = Shared.USUARIO_WEB,
                                    Saldo = montoNotaVenta,
                                    Centralizado = "NO",
                                    Periodo = DateTime.Today.Year.ToString(),
                                    Qtybultos = 0,
                                    Codlpr = Shared.LPR,
                                    Codvia = "PEN",
                                    Codadua = "PEN",
                                    Tdaduana = "PEN",
                                };
                                _context.documento.Add(notaVenta);
                                _context.SaveChanges();

                                //creo una observación para que contenga la OC asociada
                                var observacion = new DocumentoOb
                                {
                                    Obs = order.Increment_Id,
                                    Iddocto = notaVenta.Iddocto,
                                };
                                _context.documento_observacion.Add(observacion);
                                _context.SaveChanges();

                                var iLinea = 1;
                                //insertar las líneas de detalle de la orden
                                foreach (var productOrder in order.Items)
                                {
                                    var sku = productOrder.Sku.ToUpper().Trim();
                                    if (sku.Length > 15)
                                    {
                                        sku = sku.Substring(0, 15);
                                    }
                                    //reviso si existe el producto en BD IQQ
                                    var producto = _context.stock_articulo
                                                        .FirstOrDefault(p => p.Codpro == sku);
                                    double? costoUnitario = null;
                                    if (producto == null)
                                    {
                                        var excepcion = new ExcepcionOrdenProcesada
                                        {
                                            Atributo = "SKU",
                                            Excepcion = "El producto " + sku + " no está ingresado en su sistema.",
                                            ProcesoId = procesada.Id,
                                            Producto = sku,
                                        };
                                        _context.Add(excepcion);
                                        procesada.ConExcepcion = true;
                                        _context.SaveChanges();
                                    }
                                    else
                                    {
                                        costoUnitario = producto.CupMlocal;
                                    }
                                    //reviso si existe el producto en BD B010
                                    var productoEnB01 = _context.bodega_producto
                                                        .FirstOrDefault(bp =>
                                                                            bp.Codpro == sku && bp.Codbod == Shared.BODEGA_B01);
                                    if (productoEnB01 == null)
                                    {
                                        var excepcion = new ExcepcionOrdenProcesada
                                        {
                                            Atributo = "B01",
                                            Excepcion = "El producto " + sku + " no está ingresado en su bodega B01.",
                                            ProcesoId = procesada.Id,
                                            Producto = sku,
                                        };
                                        _context.Add(excepcion);
                                        procesada.ConExcepcion = true;
                                        _context.SaveChanges();
                                    }
                                    else
                                    {
                                        //aumento el stock comprometido del producto
                                        productoEnB01.Comprometido += productOrder.Qty_Ordered;
                                    }
                                    var linea = new Documentod
                                    {
                                        Iddocto = notaVenta.Iddocto,
                                        Numdoc = notaVenta.Numdoc,
                                        Td = "NVV",
                                        Sec = iLinea,
                                        Fecdoc = notaVenta.Fecdoc,
                                        Codpro = sku,
                                        Cifuni = 0,
                                        Vtauni = productOrder.Price,
                                        Cant = productOrder.Qty_Ordered,
                                        Totlin = productOrder.Price * productOrder.Qty_Ordered,
                                        Cantex = productOrder.Qty_Ordered,
                                        Cantce = 0,
                                        Paridad = 1,
                                        Responsable = Shared.RESPONSABLE_WEB,
                                        Codbod = Shared.BODEGA_B01,
                                        Ctounit = costoUnitario,
                                    };
                                    _context.documento_detalle.Add(linea);
                                    _context.SaveChanges();
                                    iLinea++;
                                }

                                //relaciono la OC con la NV creada
                                var ordenDocumento = new OrdenDocumento
                                {
                                    DocumentoId = notaVenta.Iddocto,
                                    OrdenId = procesada.Id,
                                };
                                _context.Add(ordenDocumento);
                                _context.SaveChanges();

                                var fecha = new DateTime(notaVenta.Fecdoc.Value.Year, notaVenta.Fecdoc.Value.Month, notaVenta.Fecdoc.Value.Day);
                                var paridad = _context.paridad
                                        .Where(p =>
                                                p.Fecha == fecha &&
                                                p.Moneda == "DOL")
                                        .FirstOrDefault();

                                double? valorParidad = 0;
                                if (paridad == null)
                                {
                                    var excepcion = new ExcepcionOrdenProcesada
                                    {
                                        Atributo = "Paridad",
                                        Excepcion = "Error al cargar el tipo de cambio del " + String.Format("{0:dd-MM-yyyy}", notaVenta.Fecdoc) + " desde la Base de Datos.",
                                        ProcesoId = procesada.Id
                                    };
                                    _context.Add(excepcion);
                                    procesada.ConExcepcion = true;
                                }
                                else
                                {
                                    valorParidad = paridad.Valor;
                                }

                                var formaPago = order.Payment.FormaPago;
                                if (formaPago != Shared.BANCO_MERCADOPAGO)
                                {
                                    var adicionalesPago = order.Extension_Attributes.Payment_Additional_Info;
                                    foreach (var adicional in adicionalesPago)
                                    {
                                        if (adicional.Key == "payment_method_id")
                                        {
                                            formaPago = adicional.Value;
                                        }
                                    }
                                }

                                //ahora se debe crear el pago correspondiente
                                var pago = new PagoE
                                {
                                    Rut = notaVenta.Idlegal,
                                    Tp = "TJV",
                                    Moneda = "PES",
                                    Monto = montoNotaVenta,
                                    Fecdoc = new DateTime(notaVenta.Fecdoc.Value.Year, notaVenta.Fecdoc.Value.Month, notaVenta.Fecdoc.Value.Day),
                                    Fecvenc = new DateTime(notaVenta.Fecdoc.Value.Year, notaVenta.Fecdoc.Value.Month, notaVenta.Fecdoc.Value.Day),
                                    Numcuenta = notaVenta.Numdoc,
                                    Numdocpago = "",
                                    Banco = formaPago.ToUpper(),
                                    Saldo = notaVenta.Totdoc,
                                    Mark = "1",
                                    Valdolar = valorParidad,
                                    Bol = "MAY",
                                    Fechareal = new DateTime(notaVenta.Fecdoc.Value.Year, notaVenta.Fecdoc.Value.Month, notaVenta.Fecdoc.Value.Day),
                                    Usuario = Shared.USUARIO_WEB,
                                    Impresion = "COPIA",
                                };
                                _context.Add(pago);
                                _context.SaveChanges();

                                var pagoDocumento = new PagoDocumento
                                {
                                    DocumentoId = notaVenta.Iddocto,
                                    PagoId = pago.Idpago,
                                };
                                _context.Add(pagoDocumento);

                                //Creo el pago_despacho relacionado con el PAGO_E
                                var pagoDespacho = new PagoDespacho
                                {
                                    PagoId = pago.Idpago,
                                    Monto = procesada.Despacho,
                                };
                                _context.pago_despacho.Add(pagoDespacho);

                                _context.SaveChanges();

                                transaction.Commit();
                                procesadas++;
                            }
                            catch (Exception ex)
                            {
                                transaction.Rollback();
                                _logger.Error("ERROR en la orden " + order.Increment_Id + ". " + ex.Message);
                            }
                        }
                    }
                }
                
                if(procesadas > 0)
                {
                    _logger.Info(procesadas + " órdenes nuevas procesadas correctamente.");
                }
            }
            catch (Exception ex)
            {
                if(procesadas == 0)
                {
                    _logger.Error("No se procesó ninguna orden. Error: " + ex.Message);
                }
                else
                {
                    _logger.Error("Se produjo un error, solo se procesaron " + procesadas + " órdenes correctamente. Error: " + ex.Message);
                }
            }
        }

        private void CheckModifiedStocks()
        {
            var transaction = _context.Database.BeginTransaction();
            try
            {
                var api = new API(_context);
                var actualizados = 0;
                //chequear si hay traspasos pendientes por procesar
                var traspasos = _context.traspaso.Where(t => !t.Procesado).ToList();
                if(traspasos.Count > 0)
                {
                    var actualizacion = new ActualizacionStock
                    {
                        Fecha = DateTime.Now
                    };
                    _context.Add(actualizacion);
                    _context.SaveChanges();
                    foreach (var traspaso in traspasos)
                    {
                        var documentosD = _context.documento_detalle.Where(dd => dd.Iddocto == traspaso.DocumentoId).ToList();
                        foreach (var documentoD in documentosD)
                        {
                            var sku = documentoD.Codpro;
                            var agregados = Convert.ToInt32(documentoD.Cant);
                            if (agregados > 0)
                            {
                                if (api.UpdateStock(sku, agregados).Result)
                                {
                                    var stockActualizado = new StockActualizado
                                    {
                                        ActualizacionId = actualizacion.Id,
                                        IncrementoStock = agregados,
                                        Sku = sku,
                                    };
                                    _context.Add(stockActualizado);
                                    traspaso.Procesado = true;
                                    actualizados++;
                                }
                            }
                        }
                        _context.SaveChanges();
                    }
                    transaction.Commit();
                    if (actualizados > 0)
                    {
                        _logger.Info("Se actualizó correctamente el stock de " + actualizados + " productos en Magento.");
                    }
                }
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                _logger.Error(ex.Message);
            }
            
        }

        public bool checkRepairedExceptions()
        {
            try
            {
                var api = new API(_context);
                var ordenesId = new List<int>();
                foreach (var excepcion in _context.excepcion_orden.Include(e => e.Proceso).ToList())
                {
                    var order = api.GerOrder(excepcion.Proceso.EntityId).Result;
                    if (order != null)
                    {
                        switch (excepcion.Atributo)
                        {
                            case "Fecha":
                                DateTime? fechaOrden = order.Created_At;
                                if (fechaOrden != null)
                                {
                                    _context.excepcion_orden.Remove(excepcion);
                                    if (!ordenesId.Contains(Convert.ToInt32(excepcion.ProcesoId)))
                                    {
                                        ordenesId.Add(Convert.ToInt32(excepcion.ProcesoId));
                                    }
                                }
                                break;
                            case "Rut":
                                if (order.Customer != null)
                                {
                                    if (order.Customer.Rut != null)
                                    {
                                        _context.excepcion_orden.Remove(excepcion);
                                        if (!ordenesId.Contains(Convert.ToInt32(excepcion.ProcesoId)))
                                        {
                                            ordenesId.Add(Convert.ToInt32(excepcion.ProcesoId));
                                        }
                                    }
                                }
                                break;
                            case "Nombre":
                                if (order.Customer != null)
                                {
                                    if (order.Customer.Firstname != null && order.Customer.Lastname != null)
                                    {
                                        _context.excepcion_orden.Remove(excepcion);
                                        if (!ordenesId.Contains(Convert.ToInt32(excepcion.ProcesoId)))
                                        {
                                            ordenesId.Add(Convert.ToInt32(excepcion.ProcesoId));
                                        }
                                    }
                                }
                                break;
                            case "Direccion":
                                if (order.Customer != null)
                                {
                                    if (order.Customer.Direccion != null)
                                    {
                                        _context.excepcion_orden.Remove(excepcion);
                                        if (!ordenesId.Contains(Convert.ToInt32(excepcion.ProcesoId)))
                                        {
                                            ordenesId.Add(Convert.ToInt32(excepcion.ProcesoId));
                                        }
                                    }
                                }
                                break;
                            case "Email":
                                if (order.Customer != null)
                                {
                                    if (order.Customer.Email != null)
                                    {
                                        _context.excepcion_orden.Remove(excepcion);
                                        if (!ordenesId.Contains(Convert.ToInt32(excepcion.ProcesoId)))
                                        {
                                            ordenesId.Add(Convert.ToInt32(excepcion.ProcesoId));
                                        }
                                    }
                                }
                                break;
                            case "Telefono":
                                if (order.Customer != null)
                                {
                                    if (order.Customer.Fono != null)
                                    {
                                        _context.excepcion_orden.Remove(excepcion);
                                        if (!ordenesId.Contains(Convert.ToInt32(excepcion.ProcesoId)))
                                        {
                                            ordenesId.Add(Convert.ToInt32(excepcion.ProcesoId));
                                        }
                                    }
                                }
                                break;
                            case "SKU":
                                var producto = _context.stock_articulo
                                                        .FirstOrDefault(p => p.Codpro == excepcion.Producto);
                                if (producto != null)
                                {
                                    _context.excepcion_orden.Remove(excepcion);
                                    if (!ordenesId.Contains(Convert.ToInt32(excepcion.ProcesoId)))
                                    {
                                        ordenesId.Add(Convert.ToInt32(excepcion.ProcesoId));
                                    }
                                }
                                break;
                            case "B01":
                                var productoEnB01 = _context.bodega_producto
                                                        .FirstOrDefault(bp =>
                                                            bp.Codpro == excepcion.Producto && bp.Codbod == Shared.BODEGA_B01);
                                if (productoEnB01 != null)
                                {
                                    foreach(var productOrder in order.Items){
                                        if(productOrder.Sku == productoEnB01.Codpro){
                                            //aumento el comprometido del producto en BODEGA_B01
                                            productoEnB01.Comprometido += productOrder.Qty_Ordered;
                                            break;
                                        }
                                    }
                                    _context.excepcion_orden.Remove(excepcion);
                                    if (!ordenesId.Contains(Convert.ToInt32(excepcion.ProcesoId)))
                                    {
                                        ordenesId.Add(Convert.ToInt32(excepcion.ProcesoId));
                                    }
                                }
                                break;
                            case "CostoUnitario":
                                var remove = true;
                                foreach (var product in order.Items)
                                {
                                    var sku = product.Sku.ToUpper().Trim();
                                    var stoart = _context.stock_articulo.FirstOrDefault(p => p.Codpro == sku);
                                    if (stoart == null)
                                    {
                                        remove = false;
                                        break;
                                    }
                                }
                                if (remove)
                                {
                                    _context.excepcion_orden.Remove(excepcion);
                                    if (!ordenesId.Contains(Convert.ToInt32(excepcion.ProcesoId)))
                                    {
                                        ordenesId.Add(Convert.ToInt32(excepcion.ProcesoId));
                                    }
                                }

                                break;
                            case "Paridad":
                                var fecha = new DateTime(order.Created_At.Year, order.Created_At.Month, order.Created_At.Day);
                                var paridad = _context.paridad
                                        .Where(p =>
                                                p.Fecha == fecha &&
                                                p.Moneda == "DOL")
                                        .FirstOrDefault();
                                if (paridad != null)
                                {
                                    _context.excepcion_orden.Remove(excepcion);
                                    if (!ordenesId.Contains(Convert.ToInt32(excepcion.ProcesoId)))
                                    {
                                        ordenesId.Add(Convert.ToInt32(excepcion.ProcesoId));
                                    }
                                }
                                break;
                            default:
                                break;
                        }
                    }
                    else
                    {
                        var excepcionOrden = new ExcepcionOrdenProcesada
                        {
                            Atributo = "Orden",
                            Excepcion = "Orden no puede ser obtenida desde Magento",
                            ProcesoId = excepcion.ProcesoId,
                        };
                        _context.Add(excepcionOrden);
                    }
                }
                _context.SaveChanges();

                foreach (var ordenId in ordenesId)
                {
                    var excepcionOrden = _context.excepcion_orden.FirstOrDefault(eo => eo.ProcesoId == ordenId);
                    if (excepcionOrden == null)
                    {
                        var orden = _context.orden_procesada.FirstOrDefault(op => op.Id == ordenId);
                        orden.ConExcepcion = false;
                    }
                }
                _context.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
            
        }
    }
}
