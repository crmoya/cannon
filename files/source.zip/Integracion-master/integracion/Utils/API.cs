﻿using Integracion.Data;
using Integracion.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace Integracion.Utils
{
    public class API
    {
        //diferentes endpoints que pueden consultarse
        private const string TOKEN_ENDPOINT = "integration/admin/token";
        private const string ORDERS_ENDPOINT = "orders";
        private const string CUSTOMER_ENDPOINT = "customers";
        private const string STOCKS_ENDPOINT = "stockItems";
        private const string PRODUCTS_ENDPOINT = "products";

        //token para consultas
        private string token = null;

        //URL de la API
        public const string URL_MAGENTO_API = "https://zofri.cannonhome.cl/rest/V1/";

        //usuario y clave administrador
        public const string MAGENTO_API_USERNAME = "paravena";
        public const string MAGENTO_API_PASSWORD = "12345678a";


        private readonly HttpClient _client = new HttpClient();
        private readonly Logger _logger;

        public API(AppDbContext db)
        {
            _logger = new Logger(db);
        }

        public async Task<Order> GerOrder(int Id)
        {
            Order order = null;
            try
            {
                var client = _client;
                if (token == null)
                {
                    token = await RefreshToken();
                }
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                var url = URL_MAGENTO_API + ORDERS_ENDPOINT + "/" + Id;
                var response = client.GetAsync(url).Result;
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    var responseString = response.Content.ReadAsStringAsync().Result;
                    order = JsonConvert.DeserializeObject<Order>(responseString);
                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex.Message);
                order = null;
            }
            return order;
        }

        public async Task<List<Order>> GetOrdersSince(string Status, DateTime Since)
        {
            List<Order> lista = null;
            try
            {
                var client = _client;
                if(token == null)
                {
                    token = await RefreshToken();
                }
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                var startDate = String.Format("{0:yyyy-MM-dd}", Since);
                var data = new Dictionary<string, string> {
                    { "searchCriteria[filterGroups][0][filters][0][field]", "state" },
                    { "searchCriteria[filterGroups][0][filters][0][value]", Status },
                    { "searchCriteria[filterGroups][0][filters][0][conditionType]", "eq" },
                    { "searchCriteria[filterGroups][1][filters][0][field]", "created_at" },
                    { "searchCriteria[filterGroups][1][filters][0][value]",  startDate},
                    { "searchCriteria[filterGroups][1][filters][0][conditionType]", "gt" },
                };
                var stringParams = formatParameters(data);
                var url = URL_MAGENTO_API + ORDERS_ENDPOINT + stringParams;
                var response = await client.GetAsync(url);
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    var responseString = await response.Content.ReadAsStringAsync();
                    var MultiOrders = JsonConvert.DeserializeObject<MultiResponse>(responseString);
                    lista = new List<Order>();
                    foreach(var item in MultiOrders.items)
                    {
                        
                        var order = JsonConvert.DeserializeObject<Order>(item.ToString());
                        //procesar clientes
                        var customer = new Customer
                        {
                            Email = order.Customer_Email,
                            Firstname = order.Customer_Firstname,
                            Lastname = order.Customer_Lastname,
                            CompleteRut = order.Extension_Attributes.Rut,   
                        };

                        if(order.Extension_Attributes.Shipping_Assignments != null && order.Extension_Attributes.Shipping_Assignments.Count > 0)
                        {
                            customer.Address = order.Extension_Attributes.Shipping_Assignments[0].Shipping.Address;
                        }
                        if (order.Customer_Is_Guest == 0)
                        {
                            order.Customer_Id = item.Value<int>("customer_id");
                        }
                        order.Customer = customer;
                        lista.Add(order);
                    }

                }
            }
            catch (Exception ex)
            {
                _logger.Error(ex.Message);
                lista = null;
            }
            return lista;
        }
        public async Task<bool> UpdateStock(string sku, int agregados)
        {
            var ok = false;
            try
            {
                var client = _client;
                if (token == null)
                {
                    token = await RefreshToken();
                }
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                var url = URL_MAGENTO_API + STOCKS_ENDPOINT + "/" + sku;
                var response = client.GetAsync(url).Result;
                if (response.StatusCode == HttpStatusCode.OK)
                {
                    var responseString = response.Content.ReadAsStringAsync().Result;
                    var producto = JsonConvert.DeserializeObject<Product>(responseString);
                    var url2 = URL_MAGENTO_API + PRODUCTS_ENDPOINT + "/" + sku + "/" + STOCKS_ENDPOINT + "/" + producto.Item_Id;
                    var stockItemWrapper = new StockItemWrapper
                    {
                        stockItem = new StockItem
                        {
                            is_in_stock = producto.Is_In_Stock,
                            qty = producto.Qty + agregados,
                        }
                    };
                    var stockItemStr = JsonConvert.SerializeObject(stockItemWrapper);
                    var content = new StringContent(stockItemStr, Encoding.UTF8, "application/json");
                    var response2 = client.PutAsync(url2, content).Result;
                    if (response2.StatusCode == HttpStatusCode.OK)
                    {
                        var responseString2 = response.Content.ReadAsStringAsync().Result;
                        var product = JsonConvert.DeserializeObject<Product>(responseString2);
                        if(product.Item_Id == producto.Item_Id)
                        {
                            ok = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ok = false;
                _logger.Error(ex.Message);
            }
            return ok;
        }
        private async Task<string> RefreshToken()
        {
            string token = null;
            try
            {
                var client = _client;
                var data = new Dictionary<string, string> {
                    { "username", MAGENTO_API_USERNAME },
                    { "password", MAGENTO_API_PASSWORD }
                };
                var url = URL_MAGENTO_API + TOKEN_ENDPOINT + formatParameters(data);
                var response = client.PostAsync(url, null).Result;
                if(response.StatusCode == HttpStatusCode.OK)
                {
                    var responseString = response.Content.ReadAsStringAsync().Result;
                    token = purify(responseString);
                }
            }
            catch(Exception ex)
            {
                token = null;
                _logger.Error(ex.Message);
            }
            return token;
        }
        
        private string formatParameters(Dictionary<string,string> parameters)
        {
            var stringParameters = "";
            foreach(var param in parameters)
            {
                stringParameters += param.Key + "=" + param.Value + "&";
            }
            return "?" + stringParameters.TrimEnd('&');
        }
        private string purify(string token)
        {
            return token.Replace("\"", "");
        }

    }
}
