﻿namespace Integracion.Utils
{
    public enum LogType
    {
        INFO,
        ERROR,
    }
}
