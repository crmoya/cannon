﻿using Integracion.Models;
using System.Collections.Generic;

namespace Integracion.Utils
{
    public class Util
    {
        public static string RemoveAccents(string word)
        {
            string dev = word.ToUpper();
            dev = dev.Replace("Á", "A");
            dev = dev.Replace("É", "E");
            dev = dev.Replace("Í", "I");
            dev = dev.Replace("Ó", "O");
            dev = dev.Replace("Ú", "U");
            return dev;
        }

        public static List<LineaDsm> GroupDSMLines(List<LineaDsm> lineas)
        {
            var dev = new List<LineaDsm>();
            lineas.Sort((a, b) => a.CodZeta.CompareTo(b.CodZeta));
            var codZetaAnterior = "";
            var i = 0;
            foreach(var linea in lineas)
            {
                if(codZetaAnterior == linea.CodZeta)
                {
                    dev[i-1].Cantidad += linea.Cantidad;
                    dev[i-1].Impuesto += linea.Impuesto;
                }
                else
                {
                    dev.Add(linea);
                    i++;
                }
                codZetaAnterior = linea.CodZeta;
            }
            return dev;
        }

    }
}
