﻿using Integracion.Data;
using Integracion.Entities;
using System;

namespace Integracion.Utils
{
    public class Logger
    {
        private readonly AppDbContext _context;

        public Logger(AppDbContext db)
        {
            _context = db;
        }

        public void Info(string mensaje)
        {
            try
            {
                var log = new EventLog
                {
                    Mensaje = mensaje,
                    Tipo = LogType.INFO,
                    Fecha = DateTime.Now,
                };
                _context.Add(log);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                var msg = ex.Message;
            }
        }

        public void Error(string mensaje)
        {
            try
            {
                var log = new EventLog
                {
                    Mensaje = mensaje,
                    Tipo = LogType.ERROR,
                    Fecha = DateTime.Now,
                };
                _context.Add(log);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                var msg = ex.Message;
            }
        }
    }
}
