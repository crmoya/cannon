﻿using Integracion.Data;
using Integracion.Entities;
using System;
using System.Linq;

namespace Integracion.Extensions
{
    public static class Extensions
	{
		public static double? ImpuestoDolares(this Zetart zeta, AppDbContext db)
		{
			foreach(var prefijo in Shared.PREFIJO_ZETA_IMPORTADOS)
            {
				if (zeta.Codzet.StartsWith(prefijo))
				{
					var factab = db.factabs.FirstOrDefault(f => f.Tipo == Shared.TIPO_FACTAB_IMPORTADOS && f.Codigo == Shared.CODIGO_FACTAB_IMPUESTO_ADICIONAL);
					if(factab != null)
                    {
						var factorStr = factab.Atrib4;
                        if (factorStr.Contains("."))
                        {
							factorStr = factorStr.Replace(".", ",");
                        }
						var factor = Convert.ToDouble(factorStr);
						return (factor * zeta.Cifuni) / 100;
					}
				}
			}
			return 0;
		}
	}
}
