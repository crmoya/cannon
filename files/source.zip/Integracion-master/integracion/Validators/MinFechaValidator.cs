﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Integracion.Validators
{
    public class MinFechaValidator : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if(value != null)
            {
                var fecha = (DateTime)value;
                if (fecha > new DateTime(1900,1,1))
                {
                    return ValidationResult.Success;
                }
                else
                {
                    return new ValidationResult("La fecha debe ser mayor al 1 de enero de 1900.");
                }
            }
            return ValidationResult.Success;
        }

    }
}
