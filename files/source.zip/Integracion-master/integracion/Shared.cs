﻿namespace Integracion
{
    public class Shared
    {

        public const string IQUIQUE_STORE_ID = "3";
        public const string RUT_EMPRESA = "78526430";
        public const string NOMBRE_EMPRESA = "R. CANONTEXT LTD";
        public const string BODEGA_B01 = "B01";
        public const string BODEGA_CENTRAL = "CEN";
        public const string BODEGA_B10 = "B10";
        public const string ESTADO_ORDEN_CONFIRMADA = "complete";
        public const string VENDEDOR_WEB = "WEB";
        public const string LPR = "WEB";
        public const string RESPONSABLE_WEB = "WEB";
        public const string USUARIO_WEB = "WEB";
        public const string LOCAL_M10 = "M10";
        public const string LOCAL_ECOMMERCE = "M01";
        public const string BANCO_MERCADOPAGO = "MERCADOPAGO";
        public const string BANCO_WEBPAY = "WEBPAY";

        public static string[] PREFIJO_ZETA_IMPORTADOS = { "101", "002", "001" };
        public static string[] PREFIJO_ZETA_NACIONALES = { "104", "019" };
        public const string TIPO_FACTAB_IMPORTADOS = "27";
        public const string CODIGO_FACTAB_IMPUESTO_ADICIONAL = "1";

        public const string TIPO_PROCESO_BOLETA = "BOLETA";
        public const string TIPO_PROCESO_SRF = "SRF";

        public const int CANTIDAD_PRIMERA_CARGA_MAGENTO = 999;

        public const int FRECUENCIA_EN_MINUTOS = 60;
        public const int ORDERS_SINCE_X_DAYS_AGO = 60;
    }

    public enum TAMAÑO_CELDA
    {
        XS = 30,
        SM = 50,
        MD = 100,
        LG = 200,
        XL = 300,
    }


}
