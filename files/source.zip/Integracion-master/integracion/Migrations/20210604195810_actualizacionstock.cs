﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Integracion.Migrations
{
    public partial class actualizacionstock : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "actualizacion_stock",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Fecha = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_actualizacion_stock", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "stock_actualizado",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ActualizacionId = table.Column<int>(type: "int", nullable: false),
                    Sku = table.Column<int>(type: "int", nullable: false),
                    IncrementoStock = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_stock_actualizado", x => x.Id);
                    table.ForeignKey(
                        name: "FK_stock_actualizado_actualizacion_stock_ActualizacionId",
                        column: x => x.ActualizacionId,
                        principalTable: "actualizacion_stock",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_stock_actualizado_ActualizacionId",
                table: "stock_actualizado",
                column: "ActualizacionId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "stock_actualizado");

            migrationBuilder.DropTable(
                name: "actualizacion_stock");
        }
    }
}
