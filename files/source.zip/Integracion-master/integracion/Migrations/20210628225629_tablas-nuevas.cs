﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Integracion.Migrations
{
    public partial class tablasnuevas : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
