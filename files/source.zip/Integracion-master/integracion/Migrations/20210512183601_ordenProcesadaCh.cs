﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Integracion.Migrations
{
    public partial class ordenProcesadaCh : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "NumDocSrf",
                table: "srf",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "EntityId",
                table: "orden_procesada",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "NumDocDsm",
                table: "dsm",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "NumDocBoleta",
                table: "boleta",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "NumDocSrf",
                table: "srf");

            migrationBuilder.DropColumn(
                name: "EntityId",
                table: "orden_procesada");

            migrationBuilder.DropColumn(
                name: "NumDocDsm",
                table: "dsm");

            migrationBuilder.DropColumn(
                name: "NumDocBoleta",
                table: "boleta");
        }
    }
}
