﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Integracion.Migrations
{
    public partial class srfboleta : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "boleta",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DocumentoId = table.Column<int>(type: "int", nullable: false),
                    NotaVentaId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_boleta", x => x.Id);
                    table.ForeignKey(
                        name: "FK_boleta_DOCUMENTO_DocumentoId",
                        column: x => x.DocumentoId,
                        principalTable: "DOCUMENTO",
                        principalColumn: "IDDOCTO",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_boleta_DOCUMENTO_NotaVentaId",
                        column: x => x.NotaVentaId,
                        principalTable: "DOCUMENTO",
                        principalColumn: "IDDOCTO",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "srf",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DocumentoId = table.Column<int>(type: "int", nullable: false),
                    NotaVentaId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_srf", x => x.Id);
                    table.ForeignKey(
                        name: "FK_srf_DOCUMENTO_DocumentoId",
                        column: x => x.DocumentoId,
                        principalTable: "DOCUMENTO",
                        principalColumn: "IDDOCTO",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_srf_DOCUMENTO_NotaVentaId",
                        column: x => x.NotaVentaId,
                        principalTable: "DOCUMENTO",
                        principalColumn: "IDDOCTO",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateIndex(
                name: "IX_boleta_DocumentoId",
                table: "boleta",
                column: "DocumentoId");

            migrationBuilder.CreateIndex(
                name: "IX_boleta_NotaVentaId",
                table: "boleta",
                column: "NotaVentaId");

            migrationBuilder.CreateIndex(
                name: "IX_srf_DocumentoId",
                table: "srf",
                column: "DocumentoId");

            migrationBuilder.CreateIndex(
                name: "IX_srf_NotaVentaId",
                table: "srf",
                column: "NotaVentaId");

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            
        }
    }
}
