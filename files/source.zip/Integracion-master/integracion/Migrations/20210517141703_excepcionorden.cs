﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Integracion.Migrations
{
    public partial class excepcionorden : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Producto",
                table: "excepcion_orden",
                type: "nvarchar(max)",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Producto",
                table: "excepcion_orden");
        }
    }
}
