﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Integracion.Migrations
{
    public partial class ordenpickeada : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "Pickeada",
                table: "orden_procesada",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Pickeada",
                table: "orden_procesada");
        }
    }
}
