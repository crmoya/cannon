﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Integracion.Migrations
{
    public partial class picking : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "picking",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    OrdenProcesadaId = table.Column<int>(type: "int", nullable: false),
                    DocumentoId = table.Column<int>(type: "int", nullable: false),
                    NroDocumento = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_picking", x => x.Id);
                    table.ForeignKey(
                        name: "FK_picking_DOCUMENTO_DocumentoId",
                        column: x => x.DocumentoId,
                        principalTable: "DOCUMENTO",
                        principalColumn: "IDDOCTO",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_picking_orden_procesada_OrdenProcesadaId",
                        column: x => x.OrdenProcesadaId,
                        principalTable: "orden_procesada",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_picking_DocumentoId",
                table: "picking",
                column: "DocumentoId");

            migrationBuilder.CreateIndex(
                name: "IX_picking_OrdenProcesadaId",
                table: "picking",
                column: "OrdenProcesadaId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "picking");
        }
    }
}
