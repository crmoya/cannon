﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Integracion.Migrations
{
    public partial class pickingdetalle : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "picking");

            migrationBuilder.CreateTable(
                name: "documento_picking",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    NotaVentaId = table.Column<int>(type: "int", nullable: false),
                    PickingId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_documento_picking", x => x.Id);
                    table.ForeignKey(
                        name: "FK_documento_picking_DOCUMENTO_NotaVentaId",
                        column: x => x.NotaVentaId,
                        principalTable: "DOCUMENTO",
                        principalColumn: "IDDOCTO",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_documento_picking_DOCUMENTO_PickingId",
                        column: x => x.PickingId,
                        principalTable: "DOCUMENTO",
                        principalColumn: "IDDOCTO",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateTable(
                name: "picking_linea",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    LineaNotaVentaId = table.Column<int>(type: "int", nullable: false),
                    PickingDetalleId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_picking_linea", x => x.Id);
                    table.ForeignKey(
                        name: "FK_picking_linea_DOCUMENTOD_LineaNotaVentaId",
                        column: x => x.LineaNotaVentaId,
                        principalTable: "DOCUMENTOD",
                        principalColumn: "IDDOCTOD",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_picking_linea_DOCUMENTOD_PickingDetalleId",
                        column: x => x.PickingDetalleId,
                        principalTable: "DOCUMENTOD",
                        principalColumn: "IDDOCTOD",
                        onDelete: ReferentialAction.NoAction);
                });

            migrationBuilder.CreateIndex(
                name: "IX_documento_picking_NotaVentaId",
                table: "documento_picking",
                column: "NotaVentaId");

            migrationBuilder.CreateIndex(
                name: "IX_documento_picking_PickingId",
                table: "documento_picking",
                column: "PickingId");

            migrationBuilder.CreateIndex(
                name: "IX_picking_linea_LineaNotaVentaId",
                table: "picking_linea",
                column: "LineaNotaVentaId");

            migrationBuilder.CreateIndex(
                name: "IX_picking_linea_PickingDetalleId",
                table: "picking_linea",
                column: "PickingDetalleId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "documento_picking");

            migrationBuilder.DropTable(
                name: "picking_linea");

            migrationBuilder.CreateTable(
                name: "picking",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DocumentoId = table.Column<int>(type: "int", nullable: false),
                    NotaVentaId = table.Column<int>(type: "int", nullable: false),
                    NroDocumento = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_picking", x => x.Id);
                    table.ForeignKey(
                        name: "FK_picking_DOCUMENTO_DocumentoId",
                        column: x => x.DocumentoId,
                        principalTable: "DOCUMENTO",
                        principalColumn: "IDDOCTO",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_picking_DOCUMENTO_NotaVentaId",
                        column: x => x.NotaVentaId,
                        principalTable: "DOCUMENTO",
                        principalColumn: "IDDOCTO",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_picking_DocumentoId",
                table: "picking",
                column: "DocumentoId");

            migrationBuilder.CreateIndex(
                name: "IX_picking_NotaVentaId",
                table: "picking",
                column: "NotaVentaId");
        }
    }
}
