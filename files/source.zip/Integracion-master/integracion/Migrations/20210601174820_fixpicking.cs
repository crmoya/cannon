﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Integracion.Migrations
{
    public partial class fixpicking : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_picking_orden_procesada_OrdenProcesadaId",
                table: "picking");

            migrationBuilder.RenameColumn(
                name: "OrdenProcesadaId",
                table: "picking",
                newName: "NotaVentaId");

            migrationBuilder.RenameIndex(
                name: "IX_picking_OrdenProcesadaId",
                table: "picking",
                newName: "IX_picking_NotaVentaId");

            migrationBuilder.AddForeignKey(
                name: "FK_picking_DOCUMENTO_NotaVentaId",
                table: "picking",
                column: "NotaVentaId",
                principalTable: "DOCUMENTO",
                principalColumn: "IDDOCTO",
                onDelete: ReferentialAction.NoAction);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_picking_DOCUMENTO_NotaVentaId",
                table: "picking");

            migrationBuilder.RenameColumn(
                name: "NotaVentaId",
                table: "picking",
                newName: "OrdenProcesadaId");

            migrationBuilder.RenameIndex(
                name: "IX_picking_NotaVentaId",
                table: "picking",
                newName: "IX_picking_OrdenProcesadaId");

            migrationBuilder.AddForeignKey(
                name: "FK_picking_orden_procesada_OrdenProcesadaId",
                table: "picking",
                column: "OrdenProcesadaId",
                principalTable: "orden_procesada",
                principalColumn: "Id",
                onDelete: ReferentialAction.NoAction);
        }
    }
}
