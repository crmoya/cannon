﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Integracion.Migrations
{
    public partial class tablapagodespacho : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "pago_despacho",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PagoId = table.Column<int>(type: "int", nullable: false),
                    Monto = table.Column<double>(type: "float", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_pago_despacho", x => x.Id);
                    table.ForeignKey(
                        name: "FK_pago_despacho_PAGO_E_PagoId",
                        column: x => x.PagoId,
                        principalTable: "PAGO_E",
                        principalColumn: "IDPAGO",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_pago_despacho_PagoId",
                table: "pago_despacho",
                column: "PagoId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DOCUMENTO_OBS");

            migrationBuilder.DropTable(
                name: "pago_despacho");

            migrationBuilder.DropTable(
                name: "PARAMETROS");
        }
    }
}
