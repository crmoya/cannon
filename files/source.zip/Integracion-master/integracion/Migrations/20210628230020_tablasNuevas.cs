﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Integracion.Migrations
{
    public partial class tablasNuevas : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "boleta");

            migrationBuilder.DropTable(
                name: "documento_picking");

            migrationBuilder.DropTable(
                name: "dsm");

            migrationBuilder.DropTable(
                name: "excepcion_orden");

            migrationBuilder.DropTable(
                name: "log_evento");

            migrationBuilder.DropTable(
                name: "orden_documento");

            migrationBuilder.DropTable(
                name: "pago_despacho");

            migrationBuilder.DropTable(
                name: "pago_documento");

            migrationBuilder.DropTable(
                name: "picking_linea");

            migrationBuilder.DropTable(
                name: "srf");

            migrationBuilder.DropTable(
                name: "stock_actualizado");

            migrationBuilder.DropTable(
                name: "traspaso");

            migrationBuilder.DropTable(
                name: "orden_procesada");

            migrationBuilder.DropTable(
                name: "actualizacion_stock");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "actualizacion_stock",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Fecha = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_actualizacion_stock", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "boleta",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DocumentoId = table.Column<int>(type: "int", nullable: false),
                    NotaVentaId = table.Column<int>(type: "int", nullable: false),
                    NumDocBoleta = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_boleta", x => x.Id);
                    table.ForeignKey(
                        name: "FK_boleta_DOCUMENTO_DocumentoId",
                        column: x => x.DocumentoId,
                        principalTable: "DOCUMENTO",
                        principalColumn: "IDDOCTO",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_boleta_DOCUMENTO_NotaVentaId",
                        column: x => x.NotaVentaId,
                        principalTable: "DOCUMENTO",
                        principalColumn: "IDDOCTO",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "documento_picking",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Fecha = table.Column<DateTime>(type: "datetime2", nullable: false),
                    NotaVentaId = table.Column<int>(type: "int", nullable: false),
                    PickingId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_documento_picking", x => x.Id);
                    table.ForeignKey(
                        name: "FK_documento_picking_DOCUMENTO_NotaVentaId",
                        column: x => x.NotaVentaId,
                        principalTable: "DOCUMENTO",
                        principalColumn: "IDDOCTO",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_documento_picking_DOCUMENTO_PickingId",
                        column: x => x.PickingId,
                        principalTable: "DOCUMENTO",
                        principalColumn: "IDDOCTO",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "dsm",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DocumentoId = table.Column<int>(type: "int", nullable: false),
                    NotaVentaId = table.Column<int>(type: "int", nullable: false),
                    NumDocDsm = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_dsm", x => x.Id);
                    table.ForeignKey(
                        name: "FK_dsm_DOCUMENTO_DocumentoId",
                        column: x => x.DocumentoId,
                        principalTable: "DOCUMENTO",
                        principalColumn: "IDDOCTO",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_dsm_DOCUMENTO_NotaVentaId",
                        column: x => x.NotaVentaId,
                        principalTable: "DOCUMENTO",
                        principalColumn: "IDDOCTO",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "log_evento",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Fecha = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Mensaje = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Tipo = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_log_evento", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "orden_procesada",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ConExcepcion = table.Column<bool>(type: "bit", nullable: false),
                    Despacho = table.Column<double>(type: "float", nullable: true),
                    EntityId = table.Column<int>(type: "int", nullable: false),
                    FechaImportacion = table.Column<DateTime>(type: "datetime2", nullable: false),
                    FechaProcesamiento = table.Column<DateTime>(type: "datetime2", nullable: true),
                    OrdenId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Pickeada = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_orden_procesada", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "pago_despacho",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Monto = table.Column<double>(type: "float", nullable: true),
                    PagoId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_pago_despacho", x => x.Id);
                    table.ForeignKey(
                        name: "FK_pago_despacho_PAGO_E_PagoId",
                        column: x => x.PagoId,
                        principalTable: "PAGO_E",
                        principalColumn: "IDPAGO",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "pago_documento",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DocumentoId = table.Column<int>(type: "int", nullable: false),
                    PagoId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_pago_documento", x => x.Id);
                    table.ForeignKey(
                        name: "FK_pago_documento_DOCUMENTO_DocumentoId",
                        column: x => x.DocumentoId,
                        principalTable: "DOCUMENTO",
                        principalColumn: "IDDOCTO",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_pago_documento_PAGO_E_PagoId",
                        column: x => x.PagoId,
                        principalTable: "PAGO_E",
                        principalColumn: "IDPAGO",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "picking_linea",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    LineaNotaVentaId = table.Column<int>(type: "int", nullable: false),
                    PickingDetalleId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_picking_linea", x => x.Id);
                    table.ForeignKey(
                        name: "FK_picking_linea_DOCUMENTOD_LineaNotaVentaId",
                        column: x => x.LineaNotaVentaId,
                        principalTable: "DOCUMENTOD",
                        principalColumn: "IDDOCTOD",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_picking_linea_DOCUMENTOD_PickingDetalleId",
                        column: x => x.PickingDetalleId,
                        principalTable: "DOCUMENTOD",
                        principalColumn: "IDDOCTOD",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "srf",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DocumentoId = table.Column<int>(type: "int", nullable: false),
                    NotaVentaId = table.Column<int>(type: "int", nullable: false),
                    NumDocSrf = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_srf", x => x.Id);
                    table.ForeignKey(
                        name: "FK_srf_DOCUMENTO_DocumentoId",
                        column: x => x.DocumentoId,
                        principalTable: "DOCUMENTO",
                        principalColumn: "IDDOCTO",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_srf_DOCUMENTO_NotaVentaId",
                        column: x => x.NotaVentaId,
                        principalTable: "DOCUMENTO",
                        principalColumn: "IDDOCTO",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "traspaso",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DocumentoId = table.Column<int>(type: "int", nullable: false),
                    Fecha = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Procesado = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_traspaso", x => x.Id);
                    table.ForeignKey(
                        name: "FK_traspaso_DOCUMENTO_DocumentoId",
                        column: x => x.DocumentoId,
                        principalTable: "DOCUMENTO",
                        principalColumn: "IDDOCTO",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "stock_actualizado",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ActualizacionId = table.Column<int>(type: "int", nullable: false),
                    IncrementoStock = table.Column<int>(type: "int", nullable: false),
                    Sku = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_stock_actualizado", x => x.Id);
                    table.ForeignKey(
                        name: "FK_stock_actualizado_actualizacion_stock_ActualizacionId",
                        column: x => x.ActualizacionId,
                        principalTable: "actualizacion_stock",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "excepcion_orden",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Atributo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Excepcion = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ProcesoId = table.Column<int>(type: "int", nullable: false),
                    Producto = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_excepcion_orden", x => x.Id);
                    table.ForeignKey(
                        name: "FK_excepcion_orden_orden_procesada_ProcesoId",
                        column: x => x.ProcesoId,
                        principalTable: "orden_procesada",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "orden_documento",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DocumentoId = table.Column<int>(type: "int", nullable: false),
                    OrdenId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_orden_documento", x => x.Id);
                    table.ForeignKey(
                        name: "FK_orden_documento_DOCUMENTO_DocumentoId",
                        column: x => x.DocumentoId,
                        principalTable: "DOCUMENTO",
                        principalColumn: "IDDOCTO",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_orden_documento_orden_procesada_OrdenId",
                        column: x => x.OrdenId,
                        principalTable: "orden_procesada",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_boleta_DocumentoId",
                table: "boleta",
                column: "DocumentoId");

            migrationBuilder.CreateIndex(
                name: "IX_boleta_NotaVentaId",
                table: "boleta",
                column: "NotaVentaId");

            migrationBuilder.CreateIndex(
                name: "IX_documento_picking_NotaVentaId",
                table: "documento_picking",
                column: "NotaVentaId");

            migrationBuilder.CreateIndex(
                name: "IX_documento_picking_PickingId",
                table: "documento_picking",
                column: "PickingId");

            migrationBuilder.CreateIndex(
                name: "IX_dsm_DocumentoId",
                table: "dsm",
                column: "DocumentoId");

            migrationBuilder.CreateIndex(
                name: "IX_dsm_NotaVentaId",
                table: "dsm",
                column: "NotaVentaId");

            migrationBuilder.CreateIndex(
                name: "IX_excepcion_orden_ProcesoId",
                table: "excepcion_orden",
                column: "ProcesoId");

            migrationBuilder.CreateIndex(
                name: "IX_orden_documento_DocumentoId",
                table: "orden_documento",
                column: "DocumentoId");

            migrationBuilder.CreateIndex(
                name: "IX_orden_documento_OrdenId",
                table: "orden_documento",
                column: "OrdenId");

            migrationBuilder.CreateIndex(
                name: "IX_pago_despacho_PagoId",
                table: "pago_despacho",
                column: "PagoId");

            migrationBuilder.CreateIndex(
                name: "IX_pago_documento_DocumentoId",
                table: "pago_documento",
                column: "DocumentoId");

            migrationBuilder.CreateIndex(
                name: "IX_pago_documento_PagoId",
                table: "pago_documento",
                column: "PagoId");

            migrationBuilder.CreateIndex(
                name: "IX_picking_linea_LineaNotaVentaId",
                table: "picking_linea",
                column: "LineaNotaVentaId");

            migrationBuilder.CreateIndex(
                name: "IX_picking_linea_PickingDetalleId",
                table: "picking_linea",
                column: "PickingDetalleId");

            migrationBuilder.CreateIndex(
                name: "IX_srf_DocumentoId",
                table: "srf",
                column: "DocumentoId");

            migrationBuilder.CreateIndex(
                name: "IX_srf_NotaVentaId",
                table: "srf",
                column: "NotaVentaId");

            migrationBuilder.CreateIndex(
                name: "IX_stock_actualizado_ActualizacionId",
                table: "stock_actualizado",
                column: "ActualizacionId");

            migrationBuilder.CreateIndex(
                name: "IX_traspaso_DocumentoId",
                table: "traspaso",
                column: "DocumentoId");
        }
    }
}
