﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Integracion.Migrations
{
    public partial class traspaso : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "traspaso",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DocumentoId = table.Column<int>(type: "int", nullable: false),
                    Fecha = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Procesado = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_traspaso", x => x.Id);
                    table.ForeignKey(
                        name: "FK_traspaso_DOCUMENTO_DocumentoId",
                        column: x => x.DocumentoId,
                        principalTable: "DOCUMENTO",
                        principalColumn: "IDDOCTO",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_traspaso_DocumentoId",
                table: "traspaso",
                column: "DocumentoId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "traspaso");
        }
    }
}
